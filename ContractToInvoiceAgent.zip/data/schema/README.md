# Schema

Schema mappings and column maps for structured data ingestion.
