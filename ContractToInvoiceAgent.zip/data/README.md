# Data

Input data sources, case folders, and schema mappings.
