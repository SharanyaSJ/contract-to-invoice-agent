# Cases

Create one subfolder per case. Each case folder should hold contract.pdf and workforce.xlsx for the engagement.
