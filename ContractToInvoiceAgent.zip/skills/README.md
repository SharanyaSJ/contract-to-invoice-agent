# Skills

Individual skill modules used by the agent (ingestion, extraction, mapping, computation, validation, etc.).
