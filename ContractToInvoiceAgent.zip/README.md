# ContractToInvoiceAgent

Root folder for the ContractToInvoiceAgent project. Contains orchestration files, skills, journeys, data, rules, memory stores, and outputs.
