# Output Cases

Mirrors data/cases/ structure. Stores generated invoices per engagement.
