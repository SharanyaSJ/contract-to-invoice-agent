Invoice #: kenvue_2024_001-2025-09
Period: Month 2025-09

TA Fees Due This Month:
| Employee ID | Type | Fee Type | Amount USD | Amount INR |
|-------------|------|----------|------------|------------|

OSS Fee This Month:
| GCC Headcount | Slab | Amount USD | Amount INR |
|---------------|------|------------|------------|
| 404 | OSS_PER_HEAD_51_250 | $142208.00 | ₹13346220.80 |

Monthly Total (USD): $142208.00
Monthly Total (INR): ₹13346220.80