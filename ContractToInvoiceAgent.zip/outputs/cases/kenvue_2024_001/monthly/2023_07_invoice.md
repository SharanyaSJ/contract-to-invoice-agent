Invoice #: kenvue_2024_001-2023-07
Period: Month 2023-07

TA Fees Due This Month:
| Employee ID | Type | Fee Type | Amount USD | Amount INR |
|-------------|------|----------|------------|------------|
| EMP_001 | director | Sourcing | $400.00 | ₹37540.00 |
| EMP_002 | manager | Sourcing | $400.00 | ₹37540.00 |
| EMP_010 | manager | Sourcing | $400.00 | ₹37540.00 |
| EMP_011 | non_leadership | Sourcing | $400.00 | ₹37540.00 |
| EMP_016 | non_leadership | Sourcing | $400.00 | ₹37540.00 |
| EMP_017 | manager | Sourcing | $400.00 | ₹37540.00 |
| EMP_018 | non_leadership | Sourcing | $400.00 | ₹37540.00 |
| EMP_020 | non_leadership | Sourcing | $400.00 | ₹37540.00 |
| EMP_021 | non_leadership | Sourcing | $400.00 | ₹37540.00 |
| EMP_022 | manager | Sourcing | $400.00 | ₹37540.00 |
| EMP_026 | manager | Sourcing | $400.00 | ₹37540.00 |
| EMP_029 | manager | Sourcing | $400.00 | ₹37540.00 |
| EMP_050 | non_leadership | Sourcing | $400.00 | ₹37540.00 |
| EMP_051 | manager | Sourcing | $400.00 | ₹37540.00 |
| EMP_072 | non_leadership | Sourcing | $400.00 | ₹37540.00 |
| EMP_073 | non_leadership | Sourcing | $400.00 | ₹37540.00 |
| EMP_227 | manager | Sourcing | $400.00 | ₹37540.00 |

OSS Fee This Month:
| GCC Headcount | Slab | Amount USD | Amount INR |
|---------------|------|------------|------------|
| 0 | OSS_FLAT | $17600.00 | ₹1651760.00 |

Monthly Total (USD): $24400.00
Monthly Total (INR): ₹2289940.00