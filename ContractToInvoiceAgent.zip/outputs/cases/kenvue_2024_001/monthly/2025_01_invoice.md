Invoice #: kenvue_2024_001-2025-01
Period: Month 2025-01

TA Fees Due This Month:
| Employee ID | Type | Fee Type | Amount USD | Amount INR |
|-------------|------|----------|------------|------------|
| EMP_411 | non_leadership | Sourcing | $400.00 | ₹37540.00 |
| EMP_418 | non_leadership | Sourcing | $400.00 | ₹37540.00 |
| EMP_441 | non_leadership | Sourcing | $400.00 | ₹37540.00 |
| EMP_460 | manager | Sourcing | $400.00 | ₹37540.00 |
| EMP_462 | non_leadership | Sourcing | $400.00 | ₹37540.00 |
| EMP_463 | manager | Sourcing | $400.00 | ₹37540.00 |
| EMP_465 | non_leadership | Sourcing | $400.00 | ₹37540.00 |
| EMP_467 | non_leadership | Sourcing | $400.00 | ₹37540.00 |
| EMP_470 | non_leadership | Sourcing | $400.00 | ₹37540.00 |
| EMP_482 | non_leadership | Sourcing | $400.00 | ₹37540.00 |
| EMP_483 | non_leadership | Sourcing | $400.00 | ₹37540.00 |
| EMP_502 | non_leadership | Sourcing | $400.00 | ₹37540.00 |
| EMP_506 | manager | Sourcing | $400.00 | ₹37540.00 |
| EMP_312 | manager | Acceptance | $600.00 | ₹56310.00 |
| EMP_330 | non_leadership | Acceptance | $600.00 | ₹56310.00 |
| EMP_354 | non_leadership | Acceptance | $600.00 | ₹56310.00 |
| EMP_383 | manager | Acceptance | $600.00 | ₹56310.00 |
| EMP_391 | manager | Acceptance | $600.00 | ₹56310.00 |
| EMP_394 | non_leadership | Acceptance | $600.00 | ₹56310.00 |
| EMP_396 | manager | Acceptance | $600.00 | ₹56310.00 |
| EMP_413 | non_leadership | Acceptance | $600.00 | ₹56310.00 |
| EMP_423 | non_leadership | Acceptance | $600.00 | ₹56310.00 |
| EMP_424 | non_leadership | Acceptance | $600.00 | ₹56310.00 |
| EMP_425 | non_leadership | Acceptance | $600.00 | ₹56310.00 |
| EMP_427 | non_leadership | Acceptance | $600.00 | ₹56310.00 |
| EMP_428 | non_leadership | Acceptance | $600.00 | ₹56310.00 |
| EMP_430 | non_leadership | Acceptance | $600.00 | ₹56310.00 |
| EMP_439 | non_leadership | Acceptance | $600.00 | ₹56310.00 |
| EMP_443 | non_leadership | Acceptance | $600.00 | ₹56310.00 |
| EMP_450 | non_leadership | Acceptance | $600.00 | ₹56310.00 |
| EMP_471 | manager | Acceptance | $600.00 | ₹56310.00 |
| EMP_096 | non_leadership | Balance | $214205.56 | ₹20103191.81 |
| EMP_152 | non_leadership | Balance | $133565.30 | ₹12535103.40 |
| EMP_157 | non_leadership | Balance | $-1000.00 | ₹-93850.00 |
| EMP_247 | non_leadership | Balance | $253388.23 | ₹23780485.39 |
| EMP_273 | non_leadership | Balance | $124660.29 | ₹11699368.22 |
| EMP_284 | manager | Balance | $-1000.00 | ₹-93850.00 |
| EMP_285 | non_leadership | Balance | $-1000.00 | ₹-93850.00 |
| EMP_288 | manager | Balance | $534126.83 | ₹50127803.00 |
| EMP_305 | non_leadership | Balance | $206500.96 | ₹19380115.10 |
| EMP_314 | non_leadership | Balance | $203508.19 | ₹19099243.63 |
| EMP_315 | non_leadership | Balance | $101545.91 | ₹9530083.65 |
| EMP_321 | non_leadership | Balance | $138114.94 | ₹12962087.12 |
| EMP_324 | manager | Balance | $480943.74 | ₹45136570.00 |
| EMP_327 | non_leadership | Balance | $-1000.00 | ₹-93850.00 |
| EMP_331 | manager | Balance | $798022.39 | ₹74894401.30 |
| EMP_332 | non_leadership | Balance | $163248.82 | ₹15320901.76 |
| EMP_335 | non_leadership | Balance | $137684.87 | ₹12921725.05 |
| EMP_339 | non_leadership | Balance | $367114.72 | ₹34453716.47 |
| EMP_355 | non_leadership | Balance | $124047.15 | ₹11641825.03 |
| EMP_358 | manager | Balance | $743129.30 | ₹69742684.81 |
| EMP_361 | non_leadership | Balance | $131475.64 | ₹12338988.81 |
| EMP_363 | manager | Balance | $569582.26 | ₹53455295.10 |
| EMP_373 | non_leadership | Balance | $220142.26 | ₹20660351.10 |
| EMP_374 | non_leadership | Balance | $241415.47 | ₹22656841.86 |
| EMP_392 | non_leadership | Balance | $265558.95 | ₹24922707.46 |
| EMP_395 | non_leadership | Balance | $75890.63 | ₹7122335.63 |
| EMP_403 | non_leadership | Balance | $167206.63 | ₹15692342.23 |

OSS Fee This Month:
| GCC Headcount | Slab | Amount USD | Amount INR |
|---------------|------|------------|------------|
| 289 | OSS_PER_HEAD_51_250 | $101728.00 | ₹9547172.80 |

Monthly Total (USD): $6508807.04
Monthly Total (INR): ₹610851540.70