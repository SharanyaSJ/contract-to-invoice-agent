Invoice #: kenvue_2024_001-2024-08
Period: Month 2024-08

TA Fees Due This Month:
| Employee ID | Type | Fee Type | Amount USD | Amount INR |
|-------------|------|----------|------------|------------|
| EMP_152 | non_leadership | Sourcing | $400.00 | ₹37540.00 |
| EMP_157 | non_leadership | Sourcing | $400.00 | ₹37540.00 |
| EMP_285 | non_leadership | Sourcing | $400.00 | ₹37540.00 |
| EMP_288 | manager | Sourcing | $400.00 | ₹37540.00 |
| EMP_312 | manager | Sourcing | $400.00 | ₹37540.00 |
| EMP_315 | non_leadership | Sourcing | $400.00 | ₹37540.00 |
| EMP_319 | non_leadership | Sourcing | $400.00 | ₹37540.00 |
| EMP_323 | non_leadership | Sourcing | $400.00 | ₹37540.00 |
| EMP_325 | non_leadership | Sourcing | $400.00 | ₹37540.00 |
| EMP_326 | non_leadership | Sourcing | $400.00 | ₹37540.00 |
| EMP_327 | non_leadership | Sourcing | $400.00 | ₹37540.00 |
| EMP_328 | manager | Sourcing | $400.00 | ₹37540.00 |
| EMP_331 | manager | Sourcing | $400.00 | ₹37540.00 |
| EMP_332 | non_leadership | Sourcing | $400.00 | ₹37540.00 |
| EMP_333 | non_leadership | Sourcing | $400.00 | ₹37540.00 |
| EMP_334 | non_leadership | Sourcing | $400.00 | ₹37540.00 |
| EMP_339 | non_leadership | Sourcing | $400.00 | ₹37540.00 |
| EMP_374 | non_leadership | Sourcing | $400.00 | ₹37540.00 |
| EMP_453 | manager | Sourcing | $400.00 | ₹37540.00 |
| EMP_090 | manager | Acceptance | $600.00 | ₹56310.00 |
| EMP_125 | non_leadership | Acceptance | $600.00 | ₹56310.00 |
| EMP_127 | non_leadership | Acceptance | $600.00 | ₹56310.00 |
| EMP_151 | non_leadership | Acceptance | $600.00 | ₹56310.00 |
| EMP_158 | manager | Acceptance | $600.00 | ₹56310.00 |
| EMP_171 | non_leadership | Acceptance | $600.00 | ₹56310.00 |
| EMP_175 | manager | Acceptance | $600.00 | ₹56310.00 |
| EMP_180 | non_leadership | Acceptance | $600.00 | ₹56310.00 |
| EMP_202 | manager | Acceptance | $600.00 | ₹56310.00 |
| EMP_210 | non_leadership | Acceptance | $600.00 | ₹56310.00 |
| EMP_212 | non_leadership | Acceptance | $600.00 | ₹56310.00 |
| EMP_214 | non_leadership | Acceptance | $600.00 | ₹56310.00 |
| EMP_243 | non_leadership | Acceptance | $600.00 | ₹56310.00 |
| EMP_246 | non_leadership | Acceptance | $600.00 | ₹56310.00 |
| EMP_248 | manager | Acceptance | $600.00 | ₹56310.00 |
| EMP_249 | non_leadership | Acceptance | $600.00 | ₹56310.00 |
| EMP_258 | manager | Acceptance | $600.00 | ₹56310.00 |
| EMP_264 | non_leadership | Acceptance | $600.00 | ₹56310.00 |
| EMP_267 | non_leadership | Acceptance | $600.00 | ₹56310.00 |
| EMP_272 | non_leadership | Acceptance | $600.00 | ₹56310.00 |
| EMP_278 | non_leadership | Acceptance | $600.00 | ₹56310.00 |
| EMP_325 | non_leadership | Acceptance | $600.00 | ₹56310.00 |
| EMP_342 | manager | Acceptance | $600.00 | ₹56310.00 |
| EMP_344 | non_leadership | Acceptance | $600.00 | ₹56310.00 |
| EMP_345 | non_leadership | Acceptance | $600.00 | ₹56310.00 |
| EMP_184 | manager | Balance | $510489.88 | ₹47909475.24 |
| EMP_185 | non_leadership | Balance | $157035.62 | ₹14737792.94 |
| EMP_186 | non_leadership | Balance | $-1000.00 | ₹-93850.00 |
| EMP_187 | non_leadership | Balance | $257417.22 | ₹24158606.10 |
| EMP_188 | non_leadership | Balance | $-1000.00 | ₹-93850.00 |
| EMP_189 | manager | Balance | $-1000.00 | ₹-93850.00 |
| EMP_190 | non_leadership | Balance | $266062.00 | ₹24969918.70 |
| EMP_191 | manager | Balance | $537081.43 | ₹50405092.21 |
| EMP_192 | non_leadership | Balance | $371356.01 | ₹34851761.54 |
| EMP_193 | non_leadership | Balance | $-1000.00 | ₹-93850.00 |
| EMP_194 | non_leadership | Balance | $-1000.00 | ₹-93850.00 |
| EMP_195 | non_leadership | Balance | $161265.00 | ₹15134720.25 |
| EMP_196 | manager | Balance | $688236.11 | ₹64590958.92 |
| EMP_197 | non_leadership | Balance | $168268.96 | ₹15792041.90 |
| EMP_198 | manager | Balance | $-1000.00 | ₹-93850.00 |
| EMP_199 | non_leadership | Balance | $257580.56 | ₹24173935.56 |
| EMP_200 | non_leadership | Balance | $219710.68 | ₹20619847.32 |
| EMP_201 | non_leadership | Balance | $257580.56 | ₹24173935.56 |
| EMP_203 | non_leadership | Balance | $136352.05 | ₹12796639.89 |
| EMP_205 | non_leadership | Balance | $226333.31 | ₹21241381.14 |
| EMP_207 | non_leadership | Balance | $239479.90 | ₹22475188.61 |
| EMP_209 | director | Balance | $2113266.17 | ₹198330030.05 |
| EMP_213 | non_leadership | Balance | $-1000.00 | ₹-93850.00 |
| EMP_215 | manager | Balance | $332794.11 | ₹31232727.22 |
| EMP_217 | manager | Balance | $-1000.00 | ₹-93850.00 |
| EMP_218 | non_leadership | Balance | $237515.28 | ₹22290809.03 |
| EMP_219 | non_leadership | Balance | $-1000.00 | ₹-93850.00 |
| EMP_220 | non_leadership | Balance | $-1000.00 | ₹-93850.00 |
| EMP_222 | non_leadership | Balance | $-1000.00 | ₹-93850.00 |
| EMP_223 | non_leadership | Balance | $177784.74 | ₹16685097.85 |
| EMP_224 | non_leadership | Balance | $-1000.00 | ₹-93850.00 |
| EMP_225 | manager | Balance | $-1000.00 | ₹-93850.00 |

OSS Fee This Month:
| GCC Headcount | Slab | Amount USD | Amount INR |
|---------------|------|------------|------------|
| 181 | OSS_PER_HEAD_51_250 | $63712.00 | ₹5979371.20 |

Monthly Total (USD): $7388921.59
Monthly Total (INR): ₹693450291.22