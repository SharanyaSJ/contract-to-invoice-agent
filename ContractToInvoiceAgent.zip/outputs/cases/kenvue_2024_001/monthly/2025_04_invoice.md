Invoice #: kenvue_2024_001-2025-04
Period: Month 2025-04

TA Fees Due This Month:
| Employee ID | Type | Fee Type | Amount USD | Amount INR |
|-------------|------|----------|------------|------------|
| EMP_588 | manager | Sourcing | $400.00 | ₹37540.00 |
| EMP_589 | manager | Sourcing | $400.00 | ₹37540.00 |
| EMP_590 | manager | Sourcing | $400.00 | ₹37540.00 |
| EMP_591 | non_leadership | Sourcing | $400.00 | ₹37540.00 |
| EMP_593 | non_leadership | Sourcing | $400.00 | ₹37540.00 |
| EMP_595 | non_leadership | Sourcing | $400.00 | ₹37540.00 |
| EMP_601 | manager | Sourcing | $400.00 | ₹37540.00 |
| EMP_602 | non_leadership | Sourcing | $400.00 | ₹37540.00 |
| EMP_626 | non_leadership | Sourcing | $400.00 | ₹37540.00 |
| EMP_627 | non_leadership | Sourcing | $400.00 | ₹37540.00 |
| EMP_630 | non_leadership | Sourcing | $400.00 | ₹37540.00 |
| EMP_631 | non_leadership | Sourcing | $400.00 | ₹37540.00 |
| EMP_632 | non_leadership | Sourcing | $400.00 | ₹37540.00 |
| EMP_251 | non_leadership | Acceptance | $600.00 | ₹56310.00 |
| EMP_297 | non_leadership | Acceptance | $600.00 | ₹56310.00 |
| EMP_406 | non_leadership | Acceptance | $600.00 | ₹56310.00 |
| EMP_420 | non_leadership | Acceptance | $600.00 | ₹56310.00 |
| EMP_422 | non_leadership | Acceptance | $600.00 | ₹56310.00 |
| EMP_454 | non_leadership | Acceptance | $600.00 | ₹56310.00 |
| EMP_458 | non_leadership | Acceptance | $600.00 | ₹56310.00 |
| EMP_459 | non_leadership | Acceptance | $600.00 | ₹56310.00 |
| EMP_461 | non_leadership | Acceptance | $600.00 | ₹56310.00 |
| EMP_464 | manager | Acceptance | $600.00 | ₹56310.00 |
| EMP_478 | non_leadership | Acceptance | $600.00 | ₹56310.00 |
| EMP_480 | non_leadership | Acceptance | $600.00 | ₹56310.00 |
| EMP_487 | non_leadership | Acceptance | $600.00 | ₹56310.00 |
| EMP_488 | non_leadership | Acceptance | $600.00 | ₹56310.00 |
| EMP_489 | non_leadership | Acceptance | $600.00 | ₹56310.00 |
| EMP_499 | non_leadership | Acceptance | $600.00 | ₹56310.00 |
| EMP_502 | non_leadership | Acceptance | $600.00 | ₹56310.00 |
| EMP_504 | non_leadership | Acceptance | $600.00 | ₹56310.00 |
| EMP_509 | non_leadership | Acceptance | $600.00 | ₹56310.00 |
| EMP_513 | non_leadership | Acceptance | $600.00 | ₹56310.00 |
| EMP_514 | non_leadership | Acceptance | $600.00 | ₹56310.00 |
| EMP_517 | manager | Acceptance | $600.00 | ₹56310.00 |
| EMP_525 | non_leadership | Acceptance | $600.00 | ₹56310.00 |
| EMP_538 | non_leadership | Acceptance | $600.00 | ₹56310.00 |
| EMP_539 | manager | Acceptance | $600.00 | ₹56310.00 |
| EMP_540 | non_leadership | Acceptance | $600.00 | ₹56310.00 |
| EMP_546 | non_leadership | Acceptance | $600.00 | ₹56310.00 |
| EMP_549 | non_leadership | Acceptance | $600.00 | ₹56310.00 |
| EMP_550 | non_leadership | Acceptance | $600.00 | ₹56310.00 |
| EMP_551 | non_leadership | Acceptance | $600.00 | ₹56310.00 |
| EMP_552 | non_leadership | Acceptance | $600.00 | ₹56310.00 |
| EMP_553 | non_leadership | Acceptance | $600.00 | ₹56310.00 |
| EMP_554 | non_leadership | Acceptance | $600.00 | ₹56310.00 |
| EMP_559 | non_leadership | Acceptance | $600.00 | ₹56310.00 |
| EMP_351 | non_leadership | Balance | $211731.95 | ₹19871043.51 |
| EMP_382 | manager | Balance | $593219.20 | ₹55673621.92 |
| EMP_389 | non_leadership | Balance | $186995.64 | ₹17549540.81 |
| EMP_401 | non_leadership | Balance | $85812.01 | ₹8053457.14 |
| EMP_407 | non_leadership | Balance | $-1000.00 | ₹-93850.00 |
| EMP_411 | non_leadership | Balance | $-1000.00 | ₹-93850.00 |
| EMP_414 | non_leadership | Balance | $-1000.00 | ₹-93850.00 |
| EMP_415 | non_leadership | Balance | $-1000.00 | ₹-93850.00 |
| EMP_418 | non_leadership | Balance | $158172.39 | ₹14844478.80 |
| EMP_419 | non_leadership | Balance | $188115.73 | ₹17654661.26 |
| EMP_421 | non_leadership | Balance | $102789.13 | ₹9646759.85 |
| EMP_423 | non_leadership | Balance | $84657.32 | ₹7945089.48 |
| EMP_424 | non_leadership | Balance | $203875.39 | ₹19133705.35 |
| EMP_425 | non_leadership | Balance | $-1000.00 | ₹-93850.00 |
| EMP_439 | non_leadership | Balance | $120681.29 | ₹11325939.07 |
| EMP_443 | non_leadership | Balance | $-1000.00 | ₹-93850.00 |
| EMP_457 | non_leadership | Balance | $254575.12 | ₹23891875.01 |
| EMP_465 | non_leadership | Balance | $116756.09 | ₹10957559.05 |
| EMP_470 | non_leadership | Balance | $-1000.00 | ₹-93850.00 |

OSS Fee This Month:
| GCC Headcount | Slab | Amount USD | Amount INR |
|---------------|------|------------|------------|
| 352 | OSS_PER_HEAD_51_250 | $123904.00 | ₹11628390.40 |

Monthly Total (USD): $2449885.26
Monthly Total (INR): ₹229921731.65