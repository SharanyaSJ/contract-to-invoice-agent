Invoice #: kenvue_2024_001-2023-12
Period: Month 2023-12

TA Fees Due This Month:
| Employee ID | Type | Fee Type | Amount USD | Amount INR |
|-------------|------|----------|------------|------------|
| EMP_064 | non_leadership | Sourcing | $400.00 | ₹37540.00 |
| EMP_067 | manager | Sourcing | $400.00 | ₹37540.00 |
| EMP_078 | non_leadership | Sourcing | $400.00 | ₹37540.00 |
| EMP_089 | non_leadership | Sourcing | $400.00 | ₹37540.00 |
| EMP_102 | non_leadership | Sourcing | $400.00 | ₹37540.00 |
| EMP_108 | manager | Sourcing | $400.00 | ₹37540.00 |
| EMP_122 | manager | Sourcing | $400.00 | ₹37540.00 |
| EMP_128 | director | Sourcing | $400.00 | ₹37540.00 |
| EMP_130 | non_leadership | Sourcing | $400.00 | ₹37540.00 |
| EMP_156 | non_leadership | Sourcing | $400.00 | ₹37540.00 |
| EMP_183 | non_leadership | Sourcing | $400.00 | ₹37540.00 |
| EMP_186 | non_leadership | Sourcing | $400.00 | ₹37540.00 |
| EMP_201 | non_leadership | Sourcing | $400.00 | ₹37540.00 |
| EMP_208 | manager | Sourcing | $400.00 | ₹37540.00 |
| EMP_263 | non_leadership | Sourcing | $400.00 | ₹37540.00 |
| EMP_025 | non_leadership | Acceptance | $600.00 | ₹56310.00 |
| EMP_033 | non_leadership | Acceptance | $600.00 | ₹56310.00 |
| EMP_039 | non_leadership | Acceptance | $300.00 | ₹28155.00 |
| EMP_040 | non_leadership | Acceptance | $300.00 | ₹28155.00 |
| EMP_044 | non_leadership | Acceptance | $600.00 | ₹56310.00 |
| EMP_050 | non_leadership | Acceptance | $600.00 | ₹56310.00 |
| EMP_055 | non_leadership | Acceptance | $600.00 | ₹56310.00 |
| EMP_057 | manager | Acceptance | $600.00 | ₹56310.00 |
| EMP_059 | manager | Acceptance | $600.00 | ₹56310.00 |
| EMP_060 | non_leadership | Acceptance | $300.00 | ₹28155.00 |
| EMP_061 | non_leadership | Acceptance | $300.00 | ₹28155.00 |
| EMP_062 | manager | Acceptance | $600.00 | ₹56310.00 |
| EMP_072 | non_leadership | Acceptance | $600.00 | ₹56310.00 |
| EMP_075 | manager | Acceptance | $600.00 | ₹56310.00 |
| EMP_082 | non_leadership | Acceptance | $300.00 | ₹28155.00 |
| EMP_008 | manager | Balance | $424315.00 | ₹39821962.75 |
| EMP_009 | non_leadership | Balance | $126150.00 | ₹11839177.50 |
| EMP_010 | manager | Balance | $436000.00 | ₹40918600.00 |
| EMP_011 | non_leadership | Balance | $294750.00 | ₹27662287.50 |
| EMP_012 | manager | Balance | $552850.00 | ₹51884972.50 |
| EMP_013 | non_leadership | Balance | $275697.02 | ₹25874165.33 |
| EMP_014 | non_leadership | Balance | $197729.89 | ₹18556950.18 |
| EMP_015 | non_leadership | Balance | $185300.00 | ₹17390405.00 |

OSS Fee This Month:
| GCC Headcount | Slab | Amount USD | Amount INR |
|---------------|------|------------|------------|
| 19 | OSS_FLAT | $17600.00 | ₹1651760.00 |

Monthly Total (USD): $2523891.91
Monthly Total (INR): ₹236867255.75