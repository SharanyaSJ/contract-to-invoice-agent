Invoice #: kenvue_2024_001-2024-11
Period: Month 2024-11

TA Fees Due This Month:
| Employee ID | Type | Fee Type | Amount USD | Amount INR |
|-------------|------|----------|------------|------------|
| EMP_390 | manager | Sourcing | $400.00 | ₹37540.00 |
| EMP_396 | manager | Sourcing | $400.00 | ₹37540.00 |
| EMP_403 | non_leadership | Sourcing | $400.00 | ₹37540.00 |
| EMP_406 | non_leadership | Sourcing | $400.00 | ₹37540.00 |
| EMP_407 | non_leadership | Sourcing | $400.00 | ₹37540.00 |
| EMP_417 | non_leadership | Sourcing | $400.00 | ₹37540.00 |
| EMP_419 | non_leadership | Sourcing | $400.00 | ₹37540.00 |
| EMP_420 | non_leadership | Sourcing | $400.00 | ₹37540.00 |
| EMP_421 | non_leadership | Sourcing | $400.00 | ₹37540.00 |
| EMP_422 | non_leadership | Sourcing | $400.00 | ₹37540.00 |
| EMP_425 | non_leadership | Sourcing | $400.00 | ₹37540.00 |
| EMP_426 | non_leadership | Sourcing | $400.00 | ₹37540.00 |
| EMP_427 | non_leadership | Sourcing | $400.00 | ₹37540.00 |
| EMP_428 | non_leadership | Sourcing | $400.00 | ₹37540.00 |
| EMP_429 | non_leadership | Sourcing | $400.00 | ₹37540.00 |
| EMP_431 | non_leadership | Sourcing | $400.00 | ₹37540.00 |
| EMP_440 | non_leadership | Sourcing | $400.00 | ₹37540.00 |
| EMP_443 | non_leadership | Sourcing | $400.00 | ₹37540.00 |
| EMP_452 | non_leadership | Sourcing | $400.00 | ₹37540.00 |
| EMP_457 | non_leadership | Sourcing | $400.00 | ₹37540.00 |
| EMP_517 | manager | Sourcing | $400.00 | ₹37540.00 |
| EMP_024 | non_leadership | Acceptance | $600.00 | ₹56310.00 |
| EMP_121 | non_leadership | Acceptance | $600.00 | ₹56310.00 |
| EMP_135 | non_leadership | Acceptance | $600.00 | ₹56310.00 |
| EMP_237 | manager | Acceptance | $600.00 | ₹56310.00 |
| EMP_259 | non_leadership | Acceptance | $600.00 | ₹56310.00 |
| EMP_273 | non_leadership | Acceptance | $600.00 | ₹56310.00 |
| EMP_289 | manager | Acceptance | $600.00 | ₹56310.00 |
| EMP_295 | non_leadership | Acceptance | $600.00 | ₹56310.00 |
| EMP_315 | non_leadership | Acceptance | $600.00 | ₹56310.00 |
| EMP_321 | non_leadership | Acceptance | $600.00 | ₹56310.00 |
| EMP_332 | non_leadership | Acceptance | $600.00 | ₹56310.00 |
| EMP_339 | non_leadership | Acceptance | $600.00 | ₹56310.00 |
| EMP_361 | non_leadership | Acceptance | $600.00 | ₹56310.00 |
| EMP_365 | non_leadership | Acceptance | $600.00 | ₹56310.00 |
| EMP_366 | non_leadership | Acceptance | $600.00 | ₹56310.00 |
| EMP_386 | non_leadership | Acceptance | $600.00 | ₹56310.00 |
| EMP_389 | non_leadership | Acceptance | $600.00 | ₹56310.00 |
| EMP_393 | manager | Acceptance | $600.00 | ₹56310.00 |
| EMP_403 | non_leadership | Acceptance | $600.00 | ₹56310.00 |
| EMP_127 | non_leadership | Balance | $257580.56 | ₹24173935.56 |
| EMP_151 | non_leadership | Balance | $-1000.00 | ₹-93850.00 |
| EMP_180 | non_leadership | Balance | $343284.24 | ₹32217225.92 |
| EMP_212 | non_leadership | Balance | $-1000.00 | ₹-93850.00 |
| EMP_258 | manager | Balance | $473025.30 | ₹44393424.40 |
| EMP_264 | non_leadership | Balance | $-1000.00 | ₹-93850.00 |
| EMP_268 | non_leadership | Balance | $66261.23 | ₹6218616.44 |
| EMP_287 | non_leadership | Balance | $-1000.00 | ₹-93850.00 |
| EMP_301 | manager | Balance | $620557.73 | ₹58239342.96 |
| EMP_308 | manager | Balance | $457306.79 | ₹42918242.24 |
| EMP_309 | manager | Balance | $373225.73 | ₹35027234.76 |
| EMP_310 | manager | Balance | $389398.39 | ₹36545038.90 |
| EMP_319 | non_leadership | Balance | $67442.41 | ₹6329470.18 |
| EMP_323 | non_leadership | Balance | $-1000.00 | ₹-93850.00 |
| EMP_325 | non_leadership | Balance | $84972.16 | ₹7974637.22 |
| EMP_333 | non_leadership | Balance | $51496.58 | ₹4832954.03 |
| EMP_344 | non_leadership | Balance | $135757.01 | ₹12740795.39 |
| EMP_371 | non_leadership | Balance | $259649.21 | ₹24368078.36 |
| EMP_372 | non_leadership | Balance | $214433.17 | ₹20124553.00 |

OSS Fee This Month:
| GCC Headcount | Slab | Amount USD | Amount INR |
|---------------|------|------------|------------|
| 244 | OSS_PER_HEAD_51_250 | $85888.00 | ₹8060588.80 |

Monthly Total (USD): $3895078.51
Monthly Total (INR): ₹365553118.16