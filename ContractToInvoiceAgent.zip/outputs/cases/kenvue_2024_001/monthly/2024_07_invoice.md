Invoice #: kenvue_2024_001-2024-07
Period: Month 2024-07

TA Fees Due This Month:
| Employee ID | Type | Fee Type | Amount USD | Amount INR |
|-------------|------|----------|------------|------------|
| EMP_293 | manager | Sourcing | $400.00 | ₹37540.00 |
| EMP_296 | non_leadership | Sourcing | $400.00 | ₹37540.00 |
| EMP_297 | non_leadership | Sourcing | $400.00 | ₹37540.00 |
| EMP_301 | manager | Sourcing | $400.00 | ₹37540.00 |
| EMP_302 | non_leadership | Sourcing | $400.00 | ₹37540.00 |
| EMP_305 | non_leadership | Sourcing | $400.00 | ₹37540.00 |
| EMP_307 | manager | Sourcing | $400.00 | ₹37540.00 |
| EMP_310 | manager | Sourcing | $400.00 | ₹37540.00 |
| EMP_314 | non_leadership | Sourcing | $400.00 | ₹37540.00 |
| EMP_335 | non_leadership | Sourcing | $400.00 | ₹37540.00 |
| EMP_342 | manager | Sourcing | $400.00 | ₹37540.00 |
| EMP_344 | non_leadership | Sourcing | $400.00 | ₹37540.00 |
| EMP_345 | non_leadership | Sourcing | $400.00 | ₹37540.00 |
| EMP_356 | non_leadership | Sourcing | $400.00 | ₹37540.00 |
| EMP_358 | manager | Sourcing | $400.00 | ₹37540.00 |
| EMP_360 | non_leadership | Sourcing | $400.00 | ₹37540.00 |
| EMP_361 | non_leadership | Sourcing | $400.00 | ₹37540.00 |
| EMP_370 | non_leadership | Sourcing | $400.00 | ₹37540.00 |
| EMP_371 | non_leadership | Sourcing | $400.00 | ₹37540.00 |
| EMP_372 | non_leadership | Sourcing | $400.00 | ₹37540.00 |
| EMP_546 | non_leadership | Sourcing | $400.00 | ₹37540.00 |
| EMP_685 | non_leadership | Sourcing | $400.00 | ₹37540.00 |
| EMP_213 | non_leadership | Acceptance | $600.00 | ₹56310.00 |
| EMP_215 | manager | Acceptance | $600.00 | ₹56310.00 |
| EMP_223 | non_leadership | Acceptance | $600.00 | ₹56310.00 |
| EMP_225 | manager | Acceptance | $600.00 | ₹56310.00 |
| EMP_226 | director | Acceptance | $600.00 | ₹56310.00 |
| EMP_229 | manager | Acceptance | $600.00 | ₹56310.00 |
| EMP_231 | non_leadership | Acceptance | $600.00 | ₹56310.00 |
| EMP_233 | non_leadership | Acceptance | $600.00 | ₹56310.00 |
| EMP_234 | manager | Acceptance | $600.00 | ₹56310.00 |
| EMP_235 | non_leadership | Acceptance | $600.00 | ₹56310.00 |
| EMP_236 | non_leadership | Acceptance | $600.00 | ₹56310.00 |
| EMP_244 | manager | Acceptance | $600.00 | ₹56310.00 |
| EMP_253 | manager | Acceptance | $600.00 | ₹56310.00 |
| EMP_254 | non_leadership | Acceptance | $600.00 | ₹56310.00 |
| EMP_255 | manager | Acceptance | $600.00 | ₹56310.00 |
| EMP_256 | manager | Acceptance | $600.00 | ₹56310.00 |
| EMP_263 | non_leadership | Acceptance | $600.00 | ₹56310.00 |
| EMP_265 | non_leadership | Acceptance | $600.00 | ₹56310.00 |
| EMP_268 | non_leadership | Acceptance | $600.00 | ₹56310.00 |
| EMP_269 | non_leadership | Acceptance | $600.00 | ₹56310.00 |
| EMP_277 | non_leadership | Acceptance | $600.00 | ₹56310.00 |
| EMP_282 | non_leadership | Acceptance | $600.00 | ₹56310.00 |
| EMP_290 | manager | Acceptance | $600.00 | ₹56310.00 |
| EMP_308 | manager | Acceptance | $600.00 | ₹56310.00 |
| EMP_309 | manager | Acceptance | $600.00 | ₹56310.00 |
| EMP_310 | manager | Acceptance | $600.00 | ₹56310.00 |
| EMP_343 | manager | Acceptance | $600.00 | ₹56310.00 |
| EMP_149 | non_leadership | Balance | $298953.45 | ₹28056781.28 |
| EMP_153 | manager | Balance | $560718.38 | ₹52623419.96 |
| EMP_154 | non_leadership | Balance | $273095.44 | ₹25630007.04 |
| EMP_155 | manager | Balance | $640493.10 | ₹60110277.43 |
| EMP_156 | non_leadership | Balance | $361012.79 | ₹33881050.34 |
| EMP_159 | manager | Balance | $700434.59 | ₹65735786.27 |
| EMP_160 | manager | Balance | $366704.48 | ₹34415215.45 |
| EMP_161 | non_leadership | Balance | $257580.56 | ₹24173935.56 |
| EMP_164 | non_leadership | Balance | $179118.96 | ₹16810314.40 |
| EMP_167 | non_leadership | Balance | $263165.93 | ₹24698122.53 |
| EMP_172 | non_leadership | Balance | $168268.96 | ₹15792041.90 |
| EMP_173 | non_leadership | Balance | $252408.99 | ₹23688583.71 |
| EMP_176 | non_leadership | Balance | $172447.89 | ₹16184234.48 |
| EMP_177 | manager | Balance | $560718.38 | ₹52623419.96 |
| EMP_178 | non_leadership | Balance | $-1000.00 | ₹-93850.00 |
| EMP_179 | non_leadership | Balance | $103285.76 | ₹9693368.58 |
| EMP_182 | manager | Balance | $495716.81 | ₹46523022.62 |
| EMP_183 | non_leadership | Balance | $292215.00 | ₹27424377.75 |

OSS Fee This Month:
| GCC Headcount | Slab | Amount USD | Amount INR |
|---------------|------|------------|------------|
| 162 | OSS_PER_HEAD_51_250 | $57024.00 | ₹5351702.40 |

Monthly Total (USD): $6027363.47
Monthly Total (INR): ₹565668061.66