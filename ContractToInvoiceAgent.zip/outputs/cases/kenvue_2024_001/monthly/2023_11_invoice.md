Invoice #: kenvue_2024_001-2023-11
Period: Month 2023-11

TA Fees Due This Month:
| Employee ID | Type | Fee Type | Amount USD | Amount INR |
|-------------|------|----------|------------|------------|
| EMP_038 | non_leadership | Sourcing | $400.00 | ₹37540.00 |
| EMP_048 | director | Sourcing | $400.00 | ₹37540.00 |
| EMP_053 | non_leadership | Sourcing | $300.00 | ₹28155.00 |
| EMP_085 | non_leadership | Sourcing | $300.00 | ₹28155.00 |
| EMP_100 | manager | Sourcing | $400.00 | ₹37540.00 |
| EMP_101 | manager | Sourcing | $400.00 | ₹37540.00 |
| EMP_106 | non_leadership | Sourcing | $300.00 | ₹28155.00 |
| EMP_119 | non_leadership | Sourcing | $400.00 | ₹37540.00 |
| EMP_124 | manager | Sourcing | $300.00 | ₹28155.00 |
| EMP_160 | manager | Sourcing | $300.00 | ₹28155.00 |
| EMP_184 | manager | Sourcing | $400.00 | ₹37540.00 |
| EMP_190 | non_leadership | Sourcing | $400.00 | ₹37540.00 |
| EMP_195 | non_leadership | Sourcing | $300.00 | ₹28155.00 |
| EMP_218 | non_leadership | Sourcing | $400.00 | ₹37540.00 |
| EMP_009 | non_leadership | Acceptance | $300.00 | ₹28155.00 |
| EMP_014 | non_leadership | Acceptance | $600.00 | ₹56310.00 |
| EMP_015 | non_leadership | Acceptance | $300.00 | ₹28155.00 |
| EMP_016 | non_leadership | Acceptance | $600.00 | ₹56310.00 |
| EMP_017 | manager | Acceptance | $600.00 | ₹56310.00 |
| EMP_018 | non_leadership | Acceptance | $600.00 | ₹56310.00 |
| EMP_021 | non_leadership | Acceptance | $600.00 | ₹56310.00 |
| EMP_026 | manager | Acceptance | $600.00 | ₹56310.00 |
| EMP_028 | non_leadership | Acceptance | $300.00 | ₹28155.00 |
| EMP_029 | manager | Acceptance | $600.00 | ₹56310.00 |
| EMP_030 | non_leadership | Acceptance | $300.00 | ₹28155.00 |
| EMP_031 | non_leadership | Acceptance | $600.00 | ₹56310.00 |
| EMP_035 | non_leadership | Acceptance | $600.00 | ₹56310.00 |
| EMP_036 | non_leadership | Acceptance | $600.00 | ₹56310.00 |
| EMP_037 | manager | Acceptance | $600.00 | ₹56310.00 |
| EMP_038 | non_leadership | Acceptance | $600.00 | ₹56310.00 |
| EMP_041 | manager | Acceptance | $600.00 | ₹56310.00 |
| EMP_042 | non_leadership | Acceptance | $600.00 | ₹56310.00 |
| EMP_043 | non_leadership | Acceptance | $600.00 | ₹56310.00 |
| EMP_048 | director | Acceptance | $600.00 | ₹56310.00 |
| EMP_049 | manager | Acceptance | $300.00 | ₹28155.00 |
| EMP_051 | manager | Acceptance | $600.00 | ₹56310.00 |
| EMP_052 | non_leadership | Acceptance | $600.00 | ₹56310.00 |
| EMP_054 | manager | Acceptance | $600.00 | ₹56310.00 |
| EMP_069 | non_leadership | Acceptance | $600.00 | ₹56310.00 |
| EMP_003 | non_leadership | Balance | $189205.00 | ₹17756889.25 |
| EMP_004 | manager | Balance | $244607.70 | ₹22956432.64 |
| EMP_005 | non_leadership | Balance | $277850.00 | ₹26076222.50 |
| EMP_006 | manager | Balance | $493000.00 | ₹46268050.00 |
| EMP_007 | manager | Balance | $291500.00 | ₹27357275.00 |

OSS Fee This Month:
| GCC Headcount | Slab | Amount USD | Amount INR |
|---------------|------|------------|------------|
| 14 | OSS_FLAT | $17600.00 | ₹1651760.00 |

Monthly Total (USD): $1532262.70
Monthly Total (INR): ₹143802854.39