Invoice #: kenvue_2024_001-2024-09
Period: Month 2024-09

TA Fees Due This Month:
| Employee ID | Type | Fee Type | Amount USD | Amount INR |
|-------------|------|----------|------------|------------|
| EMP_280 | non_leadership | Sourcing | $400.00 | ₹37540.00 |
| EMP_289 | manager | Sourcing | $400.00 | ₹37540.00 |
| EMP_340 | non_leadership | Sourcing | $400.00 | ₹37540.00 |
| EMP_341 | non_leadership | Sourcing | $400.00 | ₹37540.00 |
| EMP_350 | manager | Sourcing | $400.00 | ₹37540.00 |
| EMP_351 | non_leadership | Sourcing | $400.00 | ₹37540.00 |
| EMP_352 | non_leadership | Sourcing | $400.00 | ₹37540.00 |
| EMP_365 | non_leadership | Sourcing | $400.00 | ₹37540.00 |
| EMP_366 | non_leadership | Sourcing | $400.00 | ₹37540.00 |
| EMP_375 | non_leadership | Sourcing | $400.00 | ₹37540.00 |
| EMP_409 | manager | Sourcing | $400.00 | ₹37540.00 |
| EMP_002 | manager | Acceptance | $600.00 | ₹56310.00 |
| EMP_086 | non_leadership | Acceptance | $600.00 | ₹56310.00 |
| EMP_088 | non_leadership | Acceptance | $600.00 | ₹56310.00 |
| EMP_096 | non_leadership | Acceptance | $600.00 | ₹56310.00 |
| EMP_131 | non_leadership | Acceptance | $600.00 | ₹56310.00 |
| EMP_169 | manager | Acceptance | $600.00 | ₹56310.00 |
| EMP_274 | non_leadership | Acceptance | $600.00 | ₹56310.00 |
| EMP_279 | non_leadership | Acceptance | $600.00 | ₹56310.00 |
| EMP_284 | manager | Acceptance | $600.00 | ₹56310.00 |
| EMP_287 | non_leadership | Acceptance | $600.00 | ₹56310.00 |
| EMP_288 | manager | Acceptance | $600.00 | ₹56310.00 |
| EMP_293 | manager | Acceptance | $600.00 | ₹56310.00 |
| EMP_301 | manager | Acceptance | $600.00 | ₹56310.00 |
| EMP_302 | non_leadership | Acceptance | $600.00 | ₹56310.00 |
| EMP_307 | manager | Acceptance | $600.00 | ₹56310.00 |
| EMP_314 | non_leadership | Acceptance | $600.00 | ₹56310.00 |
| EMP_319 | non_leadership | Acceptance | $600.00 | ₹56310.00 |
| EMP_324 | manager | Acceptance | $600.00 | ₹56310.00 |
| EMP_326 | non_leadership | Acceptance | $600.00 | ₹56310.00 |
| EMP_335 | non_leadership | Acceptance | $600.00 | ₹56310.00 |
| EMP_363 | manager | Acceptance | $600.00 | ₹56310.00 |
| EMP_370 | non_leadership | Acceptance | $600.00 | ₹56310.00 |
| EMP_371 | non_leadership | Acceptance | $600.00 | ₹56310.00 |
| EMP_372 | non_leadership | Acceptance | $600.00 | ₹56310.00 |
| EMP_374 | non_leadership | Acceptance | $600.00 | ₹56310.00 |
| EMP_090 | manager | Balance | $397484.71 | ₹37303940.03 |
| EMP_158 | manager | Balance | $-1000.00 | ₹-93850.00 |
| EMP_175 | manager | Balance | $-1000.00 | ₹-93850.00 |
| EMP_226 | director | Balance | $-1000.00 | ₹-93850.00 |
| EMP_227 | manager | Balance | $316621.46 | ₹29714924.02 |
| EMP_228 | non_leadership | Balance | $-1000.00 | ₹-93850.00 |
| EMP_229 | manager | Balance | $-1000.00 | ₹-93850.00 |
| EMP_231 | non_leadership | Balance | $-1000.00 | ₹-93850.00 |
| EMP_233 | non_leadership | Balance | $-1000.00 | ₹-93850.00 |
| EMP_234 | manager | Balance | $457306.79 | ₹42918242.24 |
| EMP_235 | non_leadership | Balance | $165776.81 | ₹15558153.62 |
| EMP_236 | non_leadership | Balance | $-1000.00 | ₹-93850.00 |
| EMP_238 | manager | Balance | $-1000.00 | ₹-93850.00 |
| EMP_239 | non_leadership | Balance | $-1000.00 | ₹-93850.00 |
| EMP_240 | non_leadership | Balance | $174115.64 | ₹16340752.81 |
| EMP_241 | manager | Balance | $-1000.00 | ₹-93850.00 |
| EMP_244 | manager | Balance | $486852.93 | ₹45691147.48 |
| EMP_245 | non_leadership | Balance | $80750.11 | ₹7578397.82 |
| EMP_252 | non_leadership | Balance | $285507.31 | ₹26794861.04 |

OSS Fee This Month:
| GCC Headcount | Slab | Amount USD | Amount INR |
|---------------|------|------------|------------|
| 210 | OSS_PER_HEAD_51_250 | $73920.00 | ₹6937392.00 |

Monthly Total (USD): $2446735.76
Monthly Total (INR): ₹229626151.08