Invoice #: kenvue_2024_001-2025-02
Period: Month 2025-02

TA Fees Due This Month:
| Employee ID | Type | Fee Type | Amount USD | Amount INR |
|-------------|------|----------|------------|------------|
| EMP_459 | non_leadership | Sourcing | $400.00 | ₹37540.00 |
| EMP_461 | non_leadership | Sourcing | $400.00 | ₹37540.00 |
| EMP_474 | non_leadership | Sourcing | $400.00 | ₹37540.00 |
| EMP_475 | non_leadership | Sourcing | $400.00 | ₹37540.00 |
| EMP_476 | non_leadership | Sourcing | $400.00 | ₹37540.00 |
| EMP_477 | non_leadership | Sourcing | $400.00 | ₹37540.00 |
| EMP_478 | non_leadership | Sourcing | $400.00 | ₹37540.00 |
| EMP_479 | non_leadership | Sourcing | $400.00 | ₹37540.00 |
| EMP_480 | non_leadership | Sourcing | $400.00 | ₹37540.00 |
| EMP_487 | non_leadership | Sourcing | $400.00 | ₹37540.00 |
| EMP_493 | manager | Sourcing | $400.00 | ₹37540.00 |
| EMP_495 | non_leadership | Sourcing | $400.00 | ₹37540.00 |
| EMP_499 | non_leadership | Sourcing | $400.00 | ₹37540.00 |
| EMP_500 | non_leadership | Sourcing | $400.00 | ₹37540.00 |
| EMP_507 | non_leadership | Sourcing | $400.00 | ₹37540.00 |
| EMP_509 | non_leadership | Sourcing | $400.00 | ₹37540.00 |
| EMP_510 | non_leadership | Sourcing | $400.00 | ₹37540.00 |
| EMP_511 | non_leadership | Sourcing | $400.00 | ₹37540.00 |
| EMP_513 | non_leadership | Sourcing | $400.00 | ₹37540.00 |
| EMP_514 | non_leadership | Sourcing | $400.00 | ₹37540.00 |
| EMP_515 | manager | Sourcing | $400.00 | ₹37540.00 |
| EMP_530 | manager | Sourcing | $400.00 | ₹37540.00 |
| EMP_534 | non_leadership | Sourcing | $400.00 | ₹37540.00 |
| EMP_538 | non_leadership | Sourcing | $400.00 | ₹37540.00 |
| EMP_547 | manager | Sourcing | $400.00 | ₹37540.00 |
| EMP_548 | manager | Sourcing | $400.00 | ₹37540.00 |
| EMP_549 | non_leadership | Sourcing | $400.00 | ₹37540.00 |
| EMP_550 | non_leadership | Sourcing | $400.00 | ₹37540.00 |
| EMP_551 | non_leadership | Sourcing | $400.00 | ₹37540.00 |
| EMP_552 | non_leadership | Sourcing | $400.00 | ₹37540.00 |
| EMP_553 | non_leadership | Sourcing | $400.00 | ₹37540.00 |
| EMP_554 | non_leadership | Sourcing | $400.00 | ₹37540.00 |
| EMP_555 | non_leadership | Sourcing | $400.00 | ₹37540.00 |
| EMP_556 | manager | Sourcing | $400.00 | ₹37540.00 |
| EMP_586 | non_leadership | Sourcing | $400.00 | ₹37540.00 |
| EMP_587 | non_leadership | Sourcing | $400.00 | ₹37540.00 |
| EMP_624 | non_leadership | Sourcing | $400.00 | ₹37540.00 |
| EMP_629 | manager | Sourcing | $400.00 | ₹37540.00 |
| EMP_281 | non_leadership | Acceptance | $600.00 | ₹56310.00 |
| EMP_328 | manager | Acceptance | $600.00 | ₹56310.00 |
| EMP_334 | non_leadership | Acceptance | $600.00 | ₹56310.00 |
| EMP_351 | non_leadership | Acceptance | $600.00 | ₹56310.00 |
| EMP_381 | manager | Acceptance | $600.00 | ₹56310.00 |
| EMP_401 | non_leadership | Acceptance | $600.00 | ₹56310.00 |
| EMP_402 | manager | Acceptance | $600.00 | ₹56310.00 |
| EMP_407 | non_leadership | Acceptance | $600.00 | ₹56310.00 |
| EMP_411 | non_leadership | Acceptance | $600.00 | ₹56310.00 |
| EMP_418 | non_leadership | Acceptance | $600.00 | ₹56310.00 |
| EMP_437 | non_leadership | Acceptance | $600.00 | ₹56310.00 |
| EMP_441 | non_leadership | Acceptance | $600.00 | ₹56310.00 |
| EMP_455 | non_leadership | Acceptance | $600.00 | ₹56310.00 |
| EMP_457 | non_leadership | Acceptance | $600.00 | ₹56310.00 |
| EMP_463 | manager | Acceptance | $600.00 | ₹56310.00 |
| EMP_465 | non_leadership | Acceptance | $600.00 | ₹56310.00 |
| EMP_470 | non_leadership | Acceptance | $600.00 | ₹56310.00 |
| EMP_078 | non_leadership | Balance | $163248.82 | ₹15320901.76 |
| EMP_132 | manager | Balance | $324707.79 | ₹30473826.09 |
| EMP_174 | non_leadership | Balance | $168573.79 | ₹15820650.19 |
| EMP_181 | manager | Balance | $405571.04 | ₹38062842.10 |
| EMP_204 | non_leadership | Balance | $48194.86 | ₹4523087.61 |
| EMP_237 | manager | Balance | $542990.71 | ₹50959678.13 |
| EMP_250 | manager | Balance | $620816.46 | ₹58263624.77 |
| EMP_259 | non_leadership | Balance | $295287.46 | ₹27712728.12 |
| EMP_262 | manager | Balance | $405571.04 | ₹38062842.10 |
| EMP_280 | non_leadership | Balance | $168573.79 | ₹15820650.19 |
| EMP_289 | manager | Balance | $340880.43 | ₹31991628.36 |
| EMP_295 | non_leadership | Balance | $-1000.00 | ₹-93850.00 |
| EMP_356 | non_leadership | Balance | $261369.04 | ₹24529484.40 |
| EMP_357 | non_leadership | Balance | $199364.00 | ₹18710311.40 |
| EMP_375 | non_leadership | Balance | $220636.97 | ₹20706779.63 |
| EMP_383 | manager | Balance | $464397.88 | ₹43583741.04 |
| EMP_386 | non_leadership | Balance | $138017.81 | ₹12952971.47 |
| EMP_393 | manager | Balance | $510489.88 | ₹47909475.24 |

OSS Fee This Month:
| GCC Headcount | Slab | Amount USD | Amount INR |
|---------------|------|------------|------------|
| 308 | OSS_PER_HEAD_51_250 | $108416.00 | ₹10174841.60 |

Monthly Total (USD): $5411507.77
Monthly Total (INR): ₹507870004.21