Invoice #: kenvue_2024_001-2024-04
Period: Month 2024-04

TA Fees Due This Month:
| Employee ID | Type | Fee Type | Amount USD | Amount INR |
|-------------|------|----------|------------|------------|
| EMP_158 | manager | Sourcing | $400.00 | ₹37540.00 |
| EMP_168 | non_leadership | Sourcing | $400.00 | ₹37540.00 |
| EMP_169 | manager | Sourcing | $400.00 | ₹37540.00 |
| EMP_171 | non_leadership | Sourcing | $400.00 | ₹37540.00 |
| EMP_175 | manager | Sourcing | $400.00 | ₹37540.00 |
| EMP_216 | manager | Sourcing | $400.00 | ₹37540.00 |
| EMP_217 | manager | Sourcing | $400.00 | ₹37540.00 |
| EMP_220 | non_leadership | Sourcing | $400.00 | ₹37540.00 |
| EMP_222 | non_leadership | Sourcing | $400.00 | ₹37540.00 |
| EMP_226 | director | Sourcing | $400.00 | ₹37540.00 |
| EMP_240 | non_leadership | Sourcing | $400.00 | ₹37540.00 |
| EMP_248 | manager | Sourcing | $400.00 | ₹37540.00 |
| EMP_249 | non_leadership | Sourcing | $400.00 | ₹37540.00 |
| EMP_253 | manager | Sourcing | $400.00 | ₹37540.00 |
| EMP_262 | manager | Sourcing | $400.00 | ₹37540.00 |
| EMP_277 | non_leadership | Sourcing | $400.00 | ₹37540.00 |
| EMP_290 | manager | Sourcing | $400.00 | ₹37540.00 |
| EMP_430 | non_leadership | Sourcing | $400.00 | ₹37540.00 |
| EMP_594 | non_leadership | Sourcing | $400.00 | ₹37540.00 |
| EMP_115 | non_leadership | Acceptance | $600.00 | ₹56310.00 |
| EMP_116 | manager | Acceptance | $600.00 | ₹56310.00 |
| EMP_118 | non_leadership | Acceptance | $300.00 | ₹28155.00 |
| EMP_120 | non_leadership | Acceptance | $600.00 | ₹56310.00 |
| EMP_124 | manager | Acceptance | $300.00 | ₹28155.00 |
| EMP_129 | non_leadership | Acceptance | $600.00 | ₹56310.00 |
| EMP_133 | non_leadership | Acceptance | $600.00 | ₹56310.00 |
| EMP_148 | non_leadership | Acceptance | $600.00 | ₹56310.00 |
| EMP_153 | manager | Acceptance | $600.00 | ₹56310.00 |
| EMP_154 | non_leadership | Acceptance | $600.00 | ₹56310.00 |
| EMP_160 | manager | Acceptance | $300.00 | ₹28155.00 |
| EMP_164 | non_leadership | Acceptance | $600.00 | ₹56310.00 |
| EMP_173 | non_leadership | Acceptance | $600.00 | ₹56310.00 |
| EMP_176 | non_leadership | Acceptance | $600.00 | ₹56310.00 |
| EMP_184 | manager | Acceptance | $600.00 | ₹56310.00 |
| EMP_191 | manager | Acceptance | $600.00 | ₹56310.00 |
| EMP_207 | non_leadership | Acceptance | $600.00 | ₹56310.00 |
| EMP_209 | director | Acceptance | $600.00 | ₹56310.00 |
| EMP_058 | non_leadership | Balance | $168268.96 | ₹15792041.90 |
| EMP_059 | manager | Balance | $290200.00 | ₹27235270.00 |
| EMP_060 | non_leadership | Balance | $238788.50 | ₹22410300.72 |
| EMP_061 | non_leadership | Balance | $209308.14 | ₹19643568.94 |
| EMP_062 | manager | Balance | $424600.00 | ₹39848710.00 |
| EMP_063 | non_leadership | Balance | $206025.00 | ₹19335446.25 |
| EMP_064 | non_leadership | Balance | $241031.41 | ₹22620797.83 |
| EMP_067 | manager | Balance | $475034.46 | ₹44581984.07 |
| EMP_069 | non_leadership | Balance | $157015.00 | ₹14735857.75 |
| EMP_070 | manager | Balance | $512314.23 | ₹48080690.49 |
| EMP_071 | non_leadership | Balance | $108586.64 | ₹10190856.16 |
| EMP_072 | non_leadership | Balance | $100399.92 | ₹9422532.49 |
| EMP_073 | non_leadership | Balance | $171030.89 | ₹16051249.03 |
| EMP_074 | non_leadership | Balance | $245609.34 | ₹23050436.56 |

OSS Fee This Month:
| GCC Headcount | Slab | Amount USD | Amount INR |
|---------------|------|------------|------------|
| 97 | OSS_PER_HEAD_51_250 | $34144.00 | ₹3204414.40 |

Monthly Total (USD): $3599856.49
Monthly Total (INR): ₹337846531.59