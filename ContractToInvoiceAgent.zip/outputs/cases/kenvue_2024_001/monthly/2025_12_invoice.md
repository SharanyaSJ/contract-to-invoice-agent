Invoice #: kenvue_2024_001-2025-12
Period: Month 2025-12

TA Fees Due This Month:
| Employee ID | Type | Fee Type | Amount USD | Amount INR |
|-------------|------|----------|------------|------------|
| EMP_369 | non_leadership | Acceptance | $600.00 | ₹56310.00 |

OSS Fee This Month:
| GCC Headcount | Slab | Amount USD | Amount INR |
|---------------|------|------------|------------|
| 0 | N/A | $0.00 | ₹0.00 |

Monthly Total (USD): $600.00
Monthly Total (INR): ₹56310.00