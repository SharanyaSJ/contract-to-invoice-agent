Invoice #: kenvue_2024_001-2023-09
Period: Month 2023-09

TA Fees Due This Month:
| Employee ID | Type | Fee Type | Amount USD | Amount INR |
|-------------|------|----------|------------|------------|
| EMP_004 | manager | Sourcing | $400.00 | ₹37540.00 |
| EMP_006 | manager | Sourcing | $400.00 | ₹37540.00 |
| EMP_013 | non_leadership | Sourcing | $400.00 | ₹37540.00 |
| EMP_032 | non_leadership | Sourcing | $400.00 | ₹37540.00 |
| EMP_035 | non_leadership | Sourcing | $400.00 | ₹37540.00 |
| EMP_037 | manager | Sourcing | $400.00 | ₹37540.00 |
| EMP_042 | non_leadership | Sourcing | $400.00 | ₹37540.00 |
| EMP_049 | manager | Sourcing | $300.00 | ₹28155.00 |
| EMP_059 | manager | Sourcing | $400.00 | ₹37540.00 |
| EMP_087 | non_leadership | Sourcing | $400.00 | ₹37540.00 |
| EMP_105 | manager | Sourcing | $300.00 | ₹28155.00 |
| EMP_001 | director | Acceptance | $600.00 | ₹56310.00 |
| EMP_007 | manager | Acceptance | $600.00 | ₹56310.00 |
| EMP_012 | manager | Acceptance | $600.00 | ₹56310.00 |
| EMP_020 | non_leadership | Acceptance | $600.00 | ₹56310.00 |

OSS Fee This Month:
| GCC Headcount | Slab | Amount USD | Amount INR |
|---------------|------|------------|------------|
| 1 | OSS_FLAT | $17600.00 | ₹1651760.00 |

Monthly Total (USD): $24200.00
Monthly Total (INR): ₹2271170.00