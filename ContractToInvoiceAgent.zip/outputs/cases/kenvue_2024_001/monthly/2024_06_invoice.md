Invoice #: kenvue_2024_001-2024-06
Period: Month 2024-06

TA Fees Due This Month:
| Employee ID | Type | Fee Type | Amount USD | Amount INR |
|-------------|------|----------|------------|------------|
| EMP_096 | non_leadership | Sourcing | $400.00 | ₹37540.00 |
| EMP_121 | non_leadership | Sourcing | $400.00 | ₹37540.00 |
| EMP_189 | manager | Sourcing | $400.00 | ₹37540.00 |
| EMP_215 | manager | Sourcing | $400.00 | ₹37540.00 |
| EMP_234 | manager | Sourcing | $400.00 | ₹37540.00 |
| EMP_235 | non_leadership | Sourcing | $400.00 | ₹37540.00 |
| EMP_236 | non_leadership | Sourcing | $400.00 | ₹37540.00 |
| EMP_247 | non_leadership | Sourcing | $400.00 | ₹37540.00 |
| EMP_259 | non_leadership | Sourcing | $400.00 | ₹37540.00 |
| EMP_267 | non_leadership | Sourcing | $400.00 | ₹37540.00 |
| EMP_268 | non_leadership | Sourcing | $400.00 | ₹37540.00 |
| EMP_269 | non_leadership | Sourcing | $400.00 | ₹37540.00 |
| EMP_272 | non_leadership | Sourcing | $400.00 | ₹37540.00 |
| EMP_273 | non_leadership | Sourcing | $400.00 | ₹37540.00 |
| EMP_274 | non_leadership | Sourcing | $400.00 | ₹37540.00 |
| EMP_278 | non_leadership | Sourcing | $400.00 | ₹37540.00 |
| EMP_279 | non_leadership | Sourcing | $400.00 | ₹37540.00 |
| EMP_281 | non_leadership | Sourcing | $400.00 | ₹37540.00 |
| EMP_284 | manager | Sourcing | $400.00 | ₹37540.00 |
| EMP_286 | manager | Sourcing | $400.00 | ₹37540.00 |
| EMP_287 | non_leadership | Sourcing | $400.00 | ₹37540.00 |
| EMP_308 | manager | Sourcing | $400.00 | ₹37540.00 |
| EMP_330 | non_leadership | Sourcing | $400.00 | ₹37540.00 |
| EMP_343 | manager | Sourcing | $400.00 | ₹37540.00 |
| EMP_354 | non_leadership | Sourcing | $400.00 | ₹37540.00 |
| EMP_363 | manager | Sourcing | $400.00 | ₹37540.00 |
| EMP_369 | non_leadership | Sourcing | $400.00 | ₹37540.00 |
| EMP_373 | non_leadership | Sourcing | $400.00 | ₹37540.00 |
| EMP_178 | non_leadership | Acceptance | $600.00 | ₹56310.00 |
| EMP_179 | non_leadership | Acceptance | $600.00 | ₹56310.00 |
| EMP_186 | non_leadership | Acceptance | $600.00 | ₹56310.00 |
| EMP_188 | non_leadership | Acceptance | $600.00 | ₹56310.00 |
| EMP_189 | manager | Acceptance | $600.00 | ₹56310.00 |
| EMP_193 | non_leadership | Acceptance | $600.00 | ₹56310.00 |
| EMP_205 | non_leadership | Acceptance | $600.00 | ₹56310.00 |
| EMP_211 | non_leadership | Acceptance | $600.00 | ₹56310.00 |
| EMP_224 | non_leadership | Acceptance | $600.00 | ₹56310.00 |
| EMP_239 | non_leadership | Acceptance | $600.00 | ₹56310.00 |
| EMP_240 | non_leadership | Acceptance | $600.00 | ₹56310.00 |
| EMP_241 | manager | Acceptance | $600.00 | ₹56310.00 |
| EMP_242 | manager | Acceptance | $600.00 | ₹56310.00 |
| EMP_245 | non_leadership | Acceptance | $600.00 | ₹56310.00 |
| EMP_252 | non_leadership | Acceptance | $600.00 | ₹56310.00 |
| EMP_122 | manager | Balance | $433669.84 | ₹40699914.48 |
| EMP_123 | manager | Balance | $534126.83 | ₹50127803.00 |
| EMP_124 | manager | Balance | $725231.54 | ₹68062980.03 |
| EMP_128 | director | Balance | $1498732.68 | ₹140656062.02 |
| EMP_129 | non_leadership | Balance | $322742.91 | ₹30289422.10 |
| EMP_130 | non_leadership | Balance | $239479.90 | ₹22475188.61 |
| EMP_133 | non_leadership | Balance | $322742.91 | ₹30289422.10 |
| EMP_134 | non_leadership | Balance | $288610.23 | ₹27086070.09 |
| EMP_136 | manager | Balance | $560718.38 | ₹52623419.96 |
| EMP_140 | non_leadership | Balance | $183657.00 | ₹17236209.45 |
| EMP_141 | manager | Balance | $510489.88 | ₹47909475.24 |
| EMP_142 | manager | Balance | $426224.12 | ₹40001133.66 |
| EMP_144 | manager | Balance | $522308.35 | ₹49018638.65 |
| EMP_145 | non_leadership | Balance | $178527.69 | ₹16754823.71 |
| EMP_148 | non_leadership | Balance | $188273.41 | ₹17669459.53 |

OSS Fee This Month:
| GCC Headcount | Slab | Amount USD | Amount INR |
|---------------|------|------------|------------|
| 130 | OSS_PER_HEAD_51_250 | $45760.00 | ₹4294576.00 |

Monthly Total (USD): $7001495.67
Monthly Total (INR): ₹657090368.63