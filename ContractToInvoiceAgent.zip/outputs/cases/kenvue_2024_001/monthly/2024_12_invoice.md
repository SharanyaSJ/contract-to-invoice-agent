Invoice #: kenvue_2024_001-2024-12
Period: Month 2024-12

TA Fees Due This Month:
| Employee ID | Type | Fee Type | Amount USD | Amount INR |
|-------------|------|----------|------------|------------|
| EMP_397 | non_leadership | Sourcing | $400.00 | ₹37540.00 |
| EMP_423 | non_leadership | Sourcing | $400.00 | ₹37540.00 |
| EMP_450 | non_leadership | Sourcing | $400.00 | ₹37540.00 |
| EMP_451 | manager | Sourcing | $400.00 | ₹37540.00 |
| EMP_454 | non_leadership | Sourcing | $400.00 | ₹37540.00 |
| EMP_455 | non_leadership | Sourcing | $400.00 | ₹37540.00 |
| EMP_458 | non_leadership | Sourcing | $400.00 | ₹37540.00 |
| EMP_464 | manager | Sourcing | $400.00 | ₹37540.00 |
| EMP_526 | non_leadership | Sourcing | $400.00 | ₹37540.00 |
| EMP_204 | non_leadership | Acceptance | $600.00 | ₹56310.00 |
| EMP_208 | manager | Acceptance | $600.00 | ₹56310.00 |
| EMP_262 | manager | Acceptance | $600.00 | ₹56310.00 |
| EMP_286 | manager | Acceptance | $600.00 | ₹56310.00 |
| EMP_364 | manager | Acceptance | $600.00 | ₹56310.00 |
| EMP_375 | non_leadership | Acceptance | $600.00 | ₹56310.00 |
| EMP_382 | manager | Acceptance | $600.00 | ₹56310.00 |
| EMP_387 | non_leadership | Acceptance | $600.00 | ₹56310.00 |
| EMP_390 | manager | Acceptance | $600.00 | ₹56310.00 |
| EMP_392 | non_leadership | Acceptance | $600.00 | ₹56310.00 |
| EMP_395 | non_leadership | Acceptance | $600.00 | ₹56310.00 |
| EMP_397 | non_leadership | Acceptance | $600.00 | ₹56310.00 |
| EMP_412 | non_leadership | Acceptance | $600.00 | ₹56310.00 |
| EMP_414 | non_leadership | Acceptance | $600.00 | ₹56310.00 |
| EMP_415 | non_leadership | Acceptance | $600.00 | ₹56310.00 |
| EMP_421 | non_leadership | Acceptance | $600.00 | ₹56310.00 |
| EMP_431 | non_leadership | Acceptance | $600.00 | ₹56310.00 |
| EMP_453 | manager | Acceptance | $600.00 | ₹56310.00 |
| EMP_002 | manager | Balance | $486852.93 | ₹45691147.48 |
| EMP_086 | non_leadership | Balance | $88985.39 | ₹8351278.85 |
| EMP_088 | non_leadership | Balance | $168268.96 | ₹15792041.90 |
| EMP_121 | non_leadership | Balance | $299574.02 | ₹28115021.78 |
| EMP_135 | non_leadership | Balance | $169294.79 | ₹15888316.04 |
| EMP_171 | non_leadership | Balance | $262752.22 | ₹24659295.85 |
| EMP_249 | non_leadership | Balance | $267923.78 | ₹25144646.75 |
| EMP_278 | non_leadership | Balance | $-1000.00 | ₹-93850.00 |
| EMP_279 | non_leadership | Balance | $-1000.00 | ₹-93850.00 |
| EMP_290 | manager | Balance | $512314.23 | ₹48080690.49 |
| EMP_302 | non_leadership | Balance | $245209.34 | ₹23012896.56 |
| EMP_326 | non_leadership | Balance | $225816.46 | ₹21192874.77 |
| EMP_345 | non_leadership | Balance | $107776.44 | ₹10114818.89 |
| EMP_352 | non_leadership | Balance | $319639.90 | ₹29998204.62 |
| EMP_360 | non_leadership | Balance | $98707.38 | ₹9263687.61 |

OSS Fee This Month:
| GCC Headcount | Slab | Amount USD | Amount INR |
|---------------|------|------------|------------|
| 271 | OSS_PER_HEAD_51_250 | $95392.00 | ₹8952539.20 |

Monthly Total (USD): $3360907.84
Monthly Total (INR): ₹315421200.78