Invoice #: kenvue_2024_001-2025-07
Period: Month 2025-07

TA Fees Due This Month:
| Employee ID | Type | Fee Type | Amount USD | Amount INR |
|-------------|------|----------|------------|------------|
| EMP_297 | non_leadership | Balance | $172252.86 | ₹16165930.91 |
| EMP_376 | non_leadership | Balance | $328208.25 | ₹30802344.26 |
| EMP_406 | non_leadership | Balance | $-1000.00 | ₹-93850.00 |
| EMP_409 | manager | Balance | $-1000.00 | ₹-93850.00 |
| EMP_475 | non_leadership | Balance | $-1000.00 | ₹-93850.00 |
| EMP_482 | non_leadership | Balance | $-1000.00 | ₹-93850.00 |
| EMP_487 | non_leadership | Balance | $522740.43 | ₹49059189.36 |
| EMP_507 | non_leadership | Balance | $-1000.00 | ₹-93850.00 |
| EMP_509 | non_leadership | Balance | $209753.05 | ₹19685323.74 |
| EMP_511 | non_leadership | Balance | $163248.82 | ₹15320901.76 |
| EMP_517 | manager | Balance | $419722.12 | ₹39390920.96 |
| EMP_525 | non_leadership | Balance | $231612.37 | ₹21736820.92 |
| EMP_526 | non_leadership | Balance | $-1000.00 | ₹-93850.00 |
| EMP_528 | manager | Balance | $-1000.00 | ₹-93850.00 |
| EMP_530 | manager | Balance | $335220.04 | ₹31460400.75 |
| EMP_533 | manager | Balance | $-1000.00 | ₹-93850.00 |
| EMP_538 | non_leadership | Balance | $-1000.00 | ₹-93850.00 |
| EMP_540 | non_leadership | Balance | $176435.01 | ₹16558425.69 |
| EMP_549 | non_leadership | Balance | $205503.40 | ₹19286494.09 |
| EMP_550 | non_leadership | Balance | $87317.07 | ₹8194707.02 |
| EMP_551 | non_leadership | Balance | $89279.67 | ₹8378897.03 |
| EMP_552 | non_leadership | Balance | $164238.32 | ₹15413766.33 |
| EMP_553 | non_leadership | Balance | $83391.86 | ₹7826326.06 |
| EMP_554 | non_leadership | Balance | $111849.63 | ₹10497087.78 |
| EMP_588 | manager | Balance | $446002.66 | ₹41857349.64 |
| EMP_594 | non_leadership | Balance | $63674.94 | ₹5975893.12 |
| EMP_597 | manager | Balance | $419722.12 | ₹39390920.96 |
| EMP_630 | non_leadership | Balance | $-1000.00 | ₹-93850.00 |
| EMP_631 | non_leadership | Balance | $-1000.00 | ₹-93850.00 |

OSS Fee This Month:
| GCC Headcount | Slab | Amount USD | Amount INR |
|---------------|------|------------|------------|
| 404 | OSS_PER_HEAD_51_250 | $142208.00 | ₹13346220.80 |

Monthly Total (USD): $4361380.62
Monthly Total (INR): ₹409315571.19