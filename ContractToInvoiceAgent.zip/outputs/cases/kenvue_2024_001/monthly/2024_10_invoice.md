Invoice #: kenvue_2024_001-2024-10
Period: Month 2024-10

TA Fees Due This Month:
| Employee ID | Type | Fee Type | Amount USD | Amount INR |
|-------------|------|----------|------------|------------|
| EMP_181 | manager | Sourcing | $400.00 | ₹37540.00 |
| EMP_204 | non_leadership | Sourcing | $400.00 | ₹37540.00 |
| EMP_295 | non_leadership | Sourcing | $400.00 | ₹37540.00 |
| EMP_376 | non_leadership | Sourcing | $400.00 | ₹37540.00 |
| EMP_377 | non_leadership | Sourcing | $400.00 | ₹37540.00 |
| EMP_381 | manager | Sourcing | $400.00 | ₹37540.00 |
| EMP_382 | manager | Sourcing | $400.00 | ₹37540.00 |
| EMP_383 | manager | Sourcing | $400.00 | ₹37540.00 |
| EMP_386 | non_leadership | Sourcing | $400.00 | ₹37540.00 |
| EMP_387 | non_leadership | Sourcing | $400.00 | ₹37540.00 |
| EMP_389 | non_leadership | Sourcing | $400.00 | ₹37540.00 |
| EMP_391 | manager | Sourcing | $400.00 | ₹37540.00 |
| EMP_392 | non_leadership | Sourcing | $400.00 | ₹37540.00 |
| EMP_393 | manager | Sourcing | $400.00 | ₹37540.00 |
| EMP_394 | non_leadership | Sourcing | $400.00 | ₹37540.00 |
| EMP_395 | non_leadership | Sourcing | $400.00 | ₹37540.00 |
| EMP_401 | non_leadership | Sourcing | $400.00 | ₹37540.00 |
| EMP_402 | manager | Sourcing | $400.00 | ₹37540.00 |
| EMP_412 | non_leadership | Sourcing | $400.00 | ₹37540.00 |
| EMP_413 | non_leadership | Sourcing | $400.00 | ₹37540.00 |
| EMP_414 | non_leadership | Sourcing | $400.00 | ₹37540.00 |
| EMP_415 | non_leadership | Sourcing | $400.00 | ₹37540.00 |
| EMP_424 | non_leadership | Sourcing | $400.00 | ₹37540.00 |
| EMP_437 | non_leadership | Sourcing | $400.00 | ₹37540.00 |
| EMP_438 | non_leadership | Sourcing | $400.00 | ₹37540.00 |
| EMP_439 | non_leadership | Sourcing | $400.00 | ₹37540.00 |
| EMP_471 | manager | Sourcing | $400.00 | ₹37540.00 |
| EMP_472 | manager | Sourcing | $400.00 | ₹37540.00 |
| EMP_473 | manager | Sourcing | $400.00 | ₹37540.00 |
| EMP_078 | non_leadership | Acceptance | $600.00 | ₹56310.00 |
| EMP_132 | manager | Acceptance | $600.00 | ₹56310.00 |
| EMP_152 | non_leadership | Acceptance | $600.00 | ₹56310.00 |
| EMP_157 | non_leadership | Acceptance | $600.00 | ₹56310.00 |
| EMP_174 | non_leadership | Acceptance | $600.00 | ₹56310.00 |
| EMP_181 | manager | Acceptance | $600.00 | ₹56310.00 |
| EMP_247 | non_leadership | Acceptance | $600.00 | ₹56310.00 |
| EMP_250 | manager | Acceptance | $600.00 | ₹56310.00 |
| EMP_280 | non_leadership | Acceptance | $600.00 | ₹56310.00 |
| EMP_285 | non_leadership | Acceptance | $600.00 | ₹56310.00 |
| EMP_305 | non_leadership | Acceptance | $600.00 | ₹56310.00 |
| EMP_323 | non_leadership | Acceptance | $600.00 | ₹56310.00 |
| EMP_327 | non_leadership | Acceptance | $600.00 | ₹56310.00 |
| EMP_331 | manager | Acceptance | $600.00 | ₹56310.00 |
| EMP_333 | non_leadership | Acceptance | $600.00 | ₹56310.00 |
| EMP_352 | non_leadership | Acceptance | $600.00 | ₹56310.00 |
| EMP_355 | non_leadership | Acceptance | $600.00 | ₹56310.00 |
| EMP_356 | non_leadership | Acceptance | $600.00 | ₹56310.00 |
| EMP_357 | non_leadership | Acceptance | $600.00 | ₹56310.00 |
| EMP_358 | manager | Acceptance | $600.00 | ₹56310.00 |
| EMP_360 | non_leadership | Acceptance | $600.00 | ₹56310.00 |
| EMP_373 | non_leadership | Acceptance | $600.00 | ₹56310.00 |
| EMP_125 | non_leadership | Balance | $-1000.00 | ₹-93850.00 |
| EMP_131 | non_leadership | Balance | $147211.22 | ₹13815773.00 |
| EMP_169 | manager | Balance | $391209.11 | ₹36714974.97 |
| EMP_202 | manager | Balance | $455533.99 | ₹42751864.96 |
| EMP_210 | non_leadership | Balance | $-1000.00 | ₹-93850.00 |
| EMP_211 | non_leadership | Balance | $-1000.00 | ₹-93850.00 |
| EMP_214 | non_leadership | Balance | $-1000.00 | ₹-93850.00 |
| EMP_216 | manager | Balance | $340880.43 | ₹31991628.36 |
| EMP_242 | manager | Balance | $-1000.00 | ₹-93850.00 |
| EMP_243 | non_leadership | Balance | $165776.81 | ₹15558153.62 |
| EMP_246 | non_leadership | Balance | $-1000.00 | ₹-93850.00 |
| EMP_248 | manager | Balance | $-1000.00 | ₹-93850.00 |
| EMP_253 | manager | Balance | $602555.81 | ₹56549862.77 |
| EMP_254 | non_leadership | Balance | $-1000.00 | ₹-93850.00 |
| EMP_255 | manager | Balance | $-1000.00 | ₹-93850.00 |
| EMP_256 | manager | Balance | $-1000.00 | ₹-93850.00 |
| EMP_263 | non_leadership | Balance | $178527.69 | ₹16754823.71 |
| EMP_265 | non_leadership | Balance | $257580.56 | ₹24173935.56 |
| EMP_267 | non_leadership | Balance | $211036.10 | ₹19805737.98 |
| EMP_269 | non_leadership | Balance | $192461.10 | ₹18062474.23 |
| EMP_272 | non_leadership | Balance | $304125.11 | ₹28542141.57 |
| EMP_274 | non_leadership | Balance | $108173.47 | ₹10152080.16 |
| EMP_277 | non_leadership | Balance | $-1000.00 | ₹-93850.00 |
| EMP_282 | non_leadership | Balance | $134639.76 | ₹12635941.48 |
| EMP_293 | manager | Balance | $-1000.00 | ₹-93850.00 |
| EMP_307 | manager | Balance | $610976.17 | ₹57340113.55 |
| EMP_342 | manager | Balance | $472670.76 | ₹44360150.83 |
| EMP_343 | manager | Balance | $596764.80 | ₹56006376.48 |
| EMP_370 | non_leadership | Balance | $186734.66 | ₹17525047.84 |

OSS Fee This Month:
| GCC Headcount | Slab | Amount USD | Amount INR |
|---------------|------|------------|------------|
| 229 | OSS_PER_HEAD_51_250 | $80608.00 | ₹7565060.80 |

Monthly Total (USD): $5450265.55
Monthly Total (INR): ₹511507421.87