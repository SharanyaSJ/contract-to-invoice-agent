Invoice #: kenvue_2024_001-2023-08
Period: Month 2023-08

TA Fees Due This Month:
| Employee ID | Type | Fee Type | Amount USD | Amount INR |
|-------------|------|----------|------------|------------|
| EMP_003 | non_leadership | Sourcing | $400.00 | ₹37540.00 |
| EMP_005 | non_leadership | Sourcing | $400.00 | ₹37540.00 |
| EMP_007 | manager | Sourcing | $400.00 | ₹37540.00 |
| EMP_008 | manager | Sourcing | $400.00 | ₹37540.00 |
| EMP_012 | manager | Sourcing | $400.00 | ₹37540.00 |
| EMP_014 | non_leadership | Sourcing | $400.00 | ₹37540.00 |
| EMP_019 | manager | Sourcing | $400.00 | ₹37540.00 |
| EMP_023 | non_leadership | Sourcing | $400.00 | ₹37540.00 |
| EMP_024 | non_leadership | Sourcing | $400.00 | ₹37540.00 |
| EMP_025 | non_leadership | Sourcing | $400.00 | ₹37540.00 |
| EMP_027 | non_leadership | Sourcing | $400.00 | ₹37540.00 |
| EMP_031 | non_leadership | Sourcing | $400.00 | ₹37540.00 |
| EMP_033 | non_leadership | Sourcing | $400.00 | ₹37540.00 |
| EMP_034 | non_leadership | Sourcing | $400.00 | ₹37540.00 |
| EMP_041 | manager | Sourcing | $400.00 | ₹37540.00 |
| EMP_044 | non_leadership | Sourcing | $400.00 | ₹37540.00 |
| EMP_045 | manager | Sourcing | $400.00 | ₹37540.00 |
| EMP_046 | non_leadership | Sourcing | $400.00 | ₹37540.00 |
| EMP_047 | non_leadership | Sourcing | $400.00 | ₹37540.00 |
| EMP_052 | non_leadership | Sourcing | $400.00 | ₹37540.00 |
| EMP_054 | manager | Sourcing | $400.00 | ₹37540.00 |
| EMP_057 | manager | Sourcing | $400.00 | ₹37540.00 |
| EMP_058 | non_leadership | Sourcing | $400.00 | ₹37540.00 |
| EMP_062 | manager | Sourcing | $400.00 | ₹37540.00 |
| EMP_063 | non_leadership | Sourcing | $400.00 | ₹37540.00 |
| EMP_069 | non_leadership | Sourcing | $400.00 | ₹37540.00 |
| EMP_185 | non_leadership | Sourcing | $400.00 | ₹37540.00 |
| EMP_207 | non_leadership | Sourcing | $400.00 | ₹37540.00 |

OSS Fee This Month:
| GCC Headcount | Slab | Amount USD | Amount INR |
|---------------|------|------------|------------|
| 0 | OSS_FLAT | $17600.00 | ₹1651760.00 |

Monthly Total (USD): $28800.00
Monthly Total (INR): ₹2702880.00