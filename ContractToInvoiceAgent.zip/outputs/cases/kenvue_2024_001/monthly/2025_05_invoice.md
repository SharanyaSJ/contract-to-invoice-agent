Invoice #: kenvue_2024_001-2025-05
Period: Month 2025-05

TA Fees Due This Month:
| Employee ID | Type | Fee Type | Amount USD | Amount INR |
|-------------|------|----------|------------|------------|
| EMP_638 | non_leadership | Sourcing | $400.00 | ₹37540.00 |
| EMP_640 | manager | Sourcing | $400.00 | ₹37540.00 |
| EMP_646 | non_leadership | Sourcing | $400.00 | ₹37540.00 |
| EMP_660 | non_leadership | Sourcing | $400.00 | ₹37540.00 |
| EMP_661 | non_leadership | Sourcing | $400.00 | ₹37540.00 |
| EMP_662 | non_leadership | Sourcing | $400.00 | ₹37540.00 |
| EMP_663 | non_leadership | Sourcing | $400.00 | ₹37540.00 |
| EMP_296 | non_leadership | Acceptance | $600.00 | ₹56310.00 |
| EMP_350 | manager | Acceptance | $600.00 | ₹56310.00 |
| EMP_376 | non_leadership | Acceptance | $600.00 | ₹56310.00 |
| EMP_438 | non_leadership | Acceptance | $600.00 | ₹56310.00 |
| EMP_462 | non_leadership | Acceptance | $600.00 | ₹56310.00 |
| EMP_474 | non_leadership | Acceptance | $600.00 | ₹56310.00 |
| EMP_475 | non_leadership | Acceptance | $600.00 | ₹56310.00 |
| EMP_476 | non_leadership | Acceptance | $600.00 | ₹56310.00 |
| EMP_482 | non_leadership | Acceptance | $600.00 | ₹56310.00 |
| EMP_483 | non_leadership | Acceptance | $600.00 | ₹56310.00 |
| EMP_493 | manager | Acceptance | $600.00 | ₹56310.00 |
| EMP_495 | non_leadership | Acceptance | $600.00 | ₹56310.00 |
| EMP_510 | non_leadership | Acceptance | $600.00 | ₹56310.00 |
| EMP_511 | non_leadership | Acceptance | $600.00 | ₹56310.00 |
| EMP_515 | manager | Acceptance | $600.00 | ₹56310.00 |
| EMP_519 | non_leadership | Acceptance | $600.00 | ₹56310.00 |
| EMP_524 | manager | Acceptance | $600.00 | ₹56310.00 |
| EMP_529 | manager | Acceptance | $600.00 | ₹56310.00 |
| EMP_543 | manager | Acceptance | $600.00 | ₹56310.00 |
| EMP_547 | manager | Acceptance | $600.00 | ₹56310.00 |
| EMP_548 | manager | Acceptance | $600.00 | ₹56310.00 |
| EMP_586 | non_leadership | Acceptance | $600.00 | ₹56310.00 |
| EMP_588 | manager | Acceptance | $600.00 | ₹56310.00 |
| EMP_591 | non_leadership | Acceptance | $600.00 | ₹56310.00 |
| EMP_594 | non_leadership | Acceptance | $600.00 | ₹56310.00 |
| EMP_595 | non_leadership | Acceptance | $600.00 | ₹56310.00 |
| EMP_596 | manager | Acceptance | $600.00 | ₹56310.00 |
| EMP_597 | manager | Acceptance | $600.00 | ₹56310.00 |
| EMP_624 | non_leadership | Acceptance | $600.00 | ₹56310.00 |
| EMP_625 | manager | Acceptance | $600.00 | ₹56310.00 |
| EMP_626 | non_leadership | Acceptance | $600.00 | ₹56310.00 |
| EMP_627 | non_leadership | Acceptance | $600.00 | ₹56310.00 |
| EMP_628 | manager | Acceptance | $600.00 | ₹56310.00 |
| EMP_629 | manager | Acceptance | $600.00 | ₹56310.00 |
| EMP_168 | non_leadership | Balance | $245307.59 | ₹23022117.32 |
| EMP_328 | manager | Balance | $-1000.00 | ₹-93850.00 |
| EMP_334 | non_leadership | Balance | $147417.61 | ₹13835142.70 |
| EMP_377 | non_leadership | Balance | $206002.18 | ₹19333304.59 |
| EMP_381 | manager | Balance | $293384.03 | ₹27534091.22 |
| EMP_413 | non_leadership | Balance | $-1000.00 | ₹-93850.00 |
| EMP_420 | non_leadership | Balance | $308555.50 | ₹28957933.67 |
| EMP_422 | non_leadership | Balance | $422481.50 | ₹39649888.77 |
| EMP_429 | non_leadership | Balance | $-1000.00 | ₹-93850.00 |
| EMP_431 | non_leadership | Balance | $288304.22 | ₹27057351.05 |
| EMP_437 | non_leadership | Balance | $257378.64 | ₹24154985.36 |
| EMP_440 | non_leadership | Balance | $185511.45 | ₹17410249.58 |
| EMP_441 | non_leadership | Balance | $157857.21 | ₹14814899.16 |
| EMP_451 | manager | Balance | $417700.55 | ₹39201196.62 |
| EMP_452 | non_leadership | Balance | $131862.58 | ₹12375303.13 |
| EMP_453 | manager | Balance | $-1000.00 | ₹-93850.00 |
| EMP_454 | non_leadership | Balance | $-1000.00 | ₹-93850.00 |
| EMP_455 | non_leadership | Balance | $-1000.00 | ₹-93850.00 |
| EMP_458 | non_leadership | Balance | $-1000.00 | ₹-93850.00 |
| EMP_459 | non_leadership | Balance | $39278.30 | ₹3686268.46 |
| EMP_460 | manager | Balance | $-1000.00 | ₹-93850.00 |
| EMP_467 | non_leadership | Balance | $216679.17 | ₹20335340.10 |
| EMP_471 | manager | Balance | $486852.93 | ₹45691147.48 |
| EMP_472 | manager | Balance | $563673.07 | ₹52900717.62 |
| EMP_477 | non_leadership | Balance | $-1000.00 | ₹-93850.00 |
| EMP_539 | manager | Balance | $713413.11 | ₹66953820.37 |
| EMP_556 | manager | Balance | $-1000.00 | ₹-93850.00 |

OSS Fee This Month:
| GCC Headcount | Slab | Amount USD | Amount INR |
|---------------|------|------------|------------|
| 377 | OSS_PER_HEAD_51_250 | $132704.00 | ₹12454270.40 |

Monthly Total (USD): $5227563.64
Monthly Total (INR): ₹490606847.61