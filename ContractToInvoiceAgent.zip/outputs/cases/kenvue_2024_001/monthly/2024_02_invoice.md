Invoice #: kenvue_2024_001-2024-02
Period: Month 2024-02

TA Fees Due This Month:
| Employee ID | Type | Fee Type | Amount USD | Amount INR |
|-------------|------|----------|------------|------------|
| EMP_074 | non_leadership | Sourcing | $300.00 | ₹28155.00 |
| EMP_086 | non_leadership | Sourcing | $400.00 | ₹37540.00 |
| EMP_104 | non_leadership | Sourcing | $400.00 | ₹37540.00 |
| EMP_116 | manager | Sourcing | $400.00 | ₹37540.00 |
| EMP_120 | non_leadership | Sourcing | $400.00 | ₹37540.00 |
| EMP_129 | non_leadership | Sourcing | $400.00 | ₹37540.00 |
| EMP_142 | manager | Sourcing | $400.00 | ₹37540.00 |
| EMP_155 | manager | Sourcing | $400.00 | ₹37540.00 |
| EMP_161 | non_leadership | Sourcing | $400.00 | ₹37540.00 |
| EMP_167 | non_leadership | Sourcing | $400.00 | ₹37540.00 |
| EMP_172 | non_leadership | Sourcing | $400.00 | ₹37540.00 |
| EMP_173 | non_leadership | Sourcing | $400.00 | ₹37540.00 |
| EMP_177 | manager | Sourcing | $400.00 | ₹37540.00 |
| EMP_179 | non_leadership | Sourcing | $400.00 | ₹37540.00 |
| EMP_180 | non_leadership | Sourcing | $400.00 | ₹37540.00 |
| EMP_182 | manager | Sourcing | $400.00 | ₹37540.00 |
| EMP_187 | non_leadership | Sourcing | $400.00 | ₹37540.00 |
| EMP_188 | non_leadership | Sourcing | $400.00 | ₹37540.00 |
| EMP_193 | non_leadership | Sourcing | $400.00 | ₹37540.00 |
| EMP_196 | manager | Sourcing | $400.00 | ₹37540.00 |
| EMP_197 | non_leadership | Sourcing | $400.00 | ₹37540.00 |
| EMP_203 | non_leadership | Sourcing | $400.00 | ₹37540.00 |
| EMP_205 | non_leadership | Sourcing | $400.00 | ₹37540.00 |
| EMP_209 | director | Sourcing | $400.00 | ₹37540.00 |
| EMP_213 | non_leadership | Sourcing | $400.00 | ₹37540.00 |
| EMP_214 | non_leadership | Sourcing | $400.00 | ₹37540.00 |
| EMP_223 | non_leadership | Sourcing | $400.00 | ₹37540.00 |
| EMP_224 | non_leadership | Sourcing | $400.00 | ₹37540.00 |
| EMP_229 | manager | Sourcing | $400.00 | ₹37540.00 |
| EMP_231 | non_leadership | Sourcing | $400.00 | ₹37540.00 |
| EMP_243 | non_leadership | Sourcing | $400.00 | ₹37540.00 |
| EMP_245 | non_leadership | Sourcing | $400.00 | ₹37540.00 |
| EMP_250 | manager | Sourcing | $400.00 | ₹37540.00 |
| EMP_251 | non_leadership | Sourcing | $400.00 | ₹37540.00 |
| EMP_252 | non_leadership | Sourcing | $400.00 | ₹37540.00 |
| EMP_321 | non_leadership | Sourcing | $400.00 | ₹37540.00 |
| EMP_324 | manager | Sourcing | $400.00 | ₹37540.00 |
| EMP_053 | non_leadership | Acceptance | $300.00 | ₹28155.00 |
| EMP_058 | non_leadership | Acceptance | $600.00 | ₹56310.00 |
| EMP_064 | non_leadership | Acceptance | $600.00 | ₹56310.00 |
| EMP_067 | manager | Acceptance | $600.00 | ₹56310.00 |
| EMP_084 | non_leadership | Acceptance | $300.00 | ₹28155.00 |
| EMP_089 | non_leadership | Acceptance | $600.00 | ₹56310.00 |
| EMP_091 | manager | Acceptance | $600.00 | ₹56310.00 |
| EMP_097 | non_leadership | Acceptance | $600.00 | ₹56310.00 |
| EMP_099 | non_leadership | Acceptance | $600.00 | ₹56310.00 |
| EMP_100 | manager | Acceptance | $600.00 | ₹56310.00 |
| EMP_101 | manager | Acceptance | $600.00 | ₹56310.00 |
| EMP_102 | non_leadership | Acceptance | $600.00 | ₹56310.00 |
| EMP_103 | non_leadership | Acceptance | $600.00 | ₹56310.00 |
| EMP_106 | non_leadership | Acceptance | $300.00 | ₹28155.00 |
| EMP_108 | manager | Acceptance | $600.00 | ₹56310.00 |
| EMP_123 | manager | Acceptance | $600.00 | ₹56310.00 |
| EMP_136 | manager | Acceptance | $600.00 | ₹56310.00 |
| EMP_021 | non_leadership | Balance | $173400.00 | ₹16273590.00 |
| EMP_022 | manager | Balance | $560192.36 | ₹52574052.99 |
| EMP_023 | non_leadership | Balance | $156592.42 | ₹14696198.62 |
| EMP_024 | non_leadership | Balance | $-1000.00 | ₹-93850.00 |
| EMP_025 | non_leadership | Balance | $168000.00 | ₹15766800.00 |
| EMP_026 | manager | Balance | $562456.59 | ₹52786550.97 |
| EMP_027 | non_leadership | Balance | $269400.00 | ₹25283190.00 |
| EMP_028 | non_leadership | Balance | $206500.00 | ₹19380025.00 |
| EMP_029 | manager | Balance | $711500.00 | ₹66774275.00 |
| EMP_030 | non_leadership | Balance | $137980.00 | ₹12949423.00 |
| EMP_031 | non_leadership | Balance | $269769.03 | ₹25317823.47 |
| EMP_032 | non_leadership | Balance | $307425.00 | ₹28851836.25 |
| EMP_033 | non_leadership | Balance | $189632.00 | ₹17796963.20 |
| EMP_034 | non_leadership | Balance | $387700.00 | ₹36385645.00 |
| EMP_035 | non_leadership | Balance | $279962.50 | ₹26274480.62 |
| EMP_036 | non_leadership | Balance | $179407.50 | ₹16837393.88 |
| EMP_037 | manager | Balance | $493000.00 | ₹46268050.00 |
| EMP_038 | non_leadership | Balance | $100642.45 | ₹9445293.93 |
| EMP_039 | non_leadership | Balance | $177695.00 | ₹16676675.75 |
| EMP_040 | non_leadership | Balance | $276097.02 | ₹25911705.33 |
| EMP_041 | manager | Balance | $615815.48 | ₹57794282.80 |
| EMP_042 | non_leadership | Balance | $352871.04 | ₹33116947.10 |
| EMP_043 | non_leadership | Balance | $153398.50 | ₹14396449.22 |

OSS Fee This Month:
| GCC Headcount | Slab | Amount USD | Amount INR |
|---------------|------|------------|------------|
| 55 | OSS_PER_HEAD_51_250 | $19360.00 | ₹1816936.00 |

Monthly Total (USD): $6771796.89
Monthly Total (INR): ₹635533138.13