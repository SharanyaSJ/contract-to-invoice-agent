Invoice #: kenvue_2024_001-2023-10
Period: Month 2023-10

TA Fees Due This Month:
| Employee ID | Type | Fee Type | Amount USD | Amount INR |
|-------------|------|----------|------------|------------|
| EMP_009 | non_leadership | Sourcing | $300.00 | ₹28155.00 |
| EMP_015 | non_leadership | Sourcing | $300.00 | ₹28155.00 |
| EMP_028 | non_leadership | Sourcing | $300.00 | ₹28155.00 |
| EMP_030 | non_leadership | Sourcing | $300.00 | ₹28155.00 |
| EMP_036 | non_leadership | Sourcing | $400.00 | ₹37540.00 |
| EMP_039 | non_leadership | Sourcing | $300.00 | ₹28155.00 |
| EMP_040 | non_leadership | Sourcing | $300.00 | ₹28155.00 |
| EMP_043 | non_leadership | Sourcing | $400.00 | ₹37540.00 |
| EMP_055 | non_leadership | Sourcing | $400.00 | ₹37540.00 |
| EMP_060 | non_leadership | Sourcing | $300.00 | ₹28155.00 |
| EMP_061 | non_leadership | Sourcing | $300.00 | ₹28155.00 |
| EMP_075 | manager | Sourcing | $400.00 | ₹37540.00 |
| EMP_082 | non_leadership | Sourcing | $300.00 | ₹28155.00 |
| EMP_084 | non_leadership | Sourcing | $300.00 | ₹28155.00 |
| EMP_118 | non_leadership | Sourcing | $300.00 | ₹28155.00 |
| EMP_003 | non_leadership | Acceptance | $600.00 | ₹56310.00 |
| EMP_004 | manager | Acceptance | $600.00 | ₹56310.00 |
| EMP_005 | non_leadership | Acceptance | $600.00 | ₹56310.00 |
| EMP_006 | manager | Acceptance | $600.00 | ₹56310.00 |
| EMP_008 | manager | Acceptance | $600.00 | ₹56310.00 |
| EMP_010 | manager | Acceptance | $600.00 | ₹56310.00 |
| EMP_011 | non_leadership | Acceptance | $600.00 | ₹56310.00 |
| EMP_013 | non_leadership | Acceptance | $600.00 | ₹56310.00 |
| EMP_019 | manager | Acceptance | $600.00 | ₹56310.00 |
| EMP_022 | manager | Acceptance | $600.00 | ₹56310.00 |
| EMP_023 | non_leadership | Acceptance | $600.00 | ₹56310.00 |
| EMP_027 | non_leadership | Acceptance | $600.00 | ₹56310.00 |
| EMP_032 | non_leadership | Acceptance | $600.00 | ₹56310.00 |
| EMP_034 | non_leadership | Acceptance | $600.00 | ₹56310.00 |
| EMP_045 | manager | Acceptance | $600.00 | ₹56310.00 |
| EMP_001 | director | Balance | $2030525.60 | ₹190564827.56 |

OSS Fee This Month:
| GCC Headcount | Slab | Amount USD | Amount INR |
|---------------|------|------------|------------|
| 6 | OSS_FLAT | $17600.00 | ₹1651760.00 |

Monthly Total (USD): $2062025.60
Monthly Total (INR): ₹193521102.56