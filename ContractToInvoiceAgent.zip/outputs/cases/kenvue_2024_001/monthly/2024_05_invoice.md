Invoice #: kenvue_2024_001-2024-05
Period: Month 2024-05

TA Fees Due This Month:
| Employee ID | Type | Fee Type | Amount USD | Amount INR |
|-------------|------|----------|------------|------------|
| EMP_132 | manager | Sourcing | $400.00 | ₹37540.00 |
| EMP_225 | manager | Sourcing | $400.00 | ₹37540.00 |
| EMP_237 | manager | Sourcing | $400.00 | ₹37540.00 |
| EMP_241 | manager | Sourcing | $400.00 | ₹37540.00 |
| EMP_242 | manager | Sourcing | $400.00 | ₹37540.00 |
| EMP_244 | manager | Sourcing | $400.00 | ₹37540.00 |
| EMP_255 | manager | Sourcing | $400.00 | ₹37540.00 |
| EMP_309 | manager | Sourcing | $400.00 | ₹37540.00 |
| EMP_357 | non_leadership | Sourcing | $400.00 | ₹37540.00 |
| EMP_161 | non_leadership | Acceptance | $600.00 | ₹56310.00 |
| EMP_172 | non_leadership | Acceptance | $600.00 | ₹56310.00 |
| EMP_182 | manager | Acceptance | $600.00 | ₹56310.00 |
| EMP_183 | non_leadership | Acceptance | $600.00 | ₹56310.00 |
| EMP_192 | non_leadership | Acceptance | $600.00 | ₹56310.00 |
| EMP_194 | non_leadership | Acceptance | $600.00 | ₹56310.00 |
| EMP_195 | non_leadership | Acceptance | $300.00 | ₹28155.00 |
| EMP_196 | manager | Acceptance | $600.00 | ₹56310.00 |
| EMP_197 | non_leadership | Acceptance | $600.00 | ₹56310.00 |
| EMP_198 | manager | Acceptance | $600.00 | ₹56310.00 |
| EMP_199 | non_leadership | Acceptance | $600.00 | ₹56310.00 |
| EMP_200 | non_leadership | Acceptance | $300.00 | ₹28155.00 |
| EMP_201 | non_leadership | Acceptance | $600.00 | ₹56310.00 |
| EMP_203 | non_leadership | Acceptance | $600.00 | ₹56310.00 |
| EMP_216 | manager | Acceptance | $600.00 | ₹56310.00 |
| EMP_217 | manager | Acceptance | $600.00 | ₹56310.00 |
| EMP_218 | non_leadership | Acceptance | $600.00 | ₹56310.00 |
| EMP_219 | non_leadership | Acceptance | $600.00 | ₹56310.00 |
| EMP_220 | non_leadership | Acceptance | $600.00 | ₹56310.00 |
| EMP_222 | non_leadership | Acceptance | $600.00 | ₹56310.00 |
| EMP_227 | manager | Acceptance | $600.00 | ₹56310.00 |
| EMP_228 | non_leadership | Acceptance | $600.00 | ₹56310.00 |
| EMP_238 | manager | Acceptance | $600.00 | ₹56310.00 |
| EMP_075 | manager | Balance | $369500.00 | ₹34677575.00 |
| EMP_076 | non_leadership | Balance | $239479.90 | ₹22475188.61 |
| EMP_077 | non_leadership | Balance | $239479.90 | ₹22475188.61 |
| EMP_080 | manager | Balance | $424805.96 | ₹39868039.35 |
| EMP_081 | non_leadership | Balance | $239479.90 | ₹22475188.61 |
| EMP_082 | non_leadership | Balance | $173800.00 | ₹16311130.00 |
| EMP_084 | non_leadership | Balance | $135039.76 | ₹12673481.48 |
| EMP_085 | non_leadership | Balance | $226950.89 | ₹21299341.03 |
| EMP_087 | non_leadership | Balance | $273095.44 | ₹25630007.04 |
| EMP_089 | non_leadership | Balance | $304642.25 | ₹28590675.16 |
| EMP_091 | manager | Balance | $449716.83 | ₹42205924.50 |
| EMP_097 | non_leadership | Balance | $159651.57 | ₹14983299.84 |
| EMP_099 | non_leadership | Balance | $121406.62 | ₹11394011.29 |
| EMP_100 | manager | Balance | $657739.97 | ₹61728896.18 |
| EMP_101 | manager | Balance | $570738.51 | ₹53563809.16 |
| EMP_102 | non_leadership | Balance | $163139.56 | ₹15310647.71 |
| EMP_103 | non_leadership | Balance | $232487.54 | ₹21818955.63 |
| EMP_104 | non_leadership | Balance | $156984.33 | ₹14732979.37 |
| EMP_105 | manager | Balance | $486900.00 | ₹45695565.00 |
| EMP_106 | non_leadership | Balance | $268323.78 | ₹25182186.75 |
| EMP_108 | manager | Balance | $486852.93 | ₹45691147.48 |
| EMP_109 | non_leadership | Balance | $288610.23 | ₹27086070.09 |
| EMP_115 | non_leadership | Balance | $226743.64 | ₹21279890.61 |
| EMP_116 | manager | Balance | $648766.08 | ₹60886696.61 |
| EMP_117 | non_leadership | Balance | $292399.46 | ₹27441689.32 |
| EMP_118 | non_leadership | Balance | $177851.20 | ₹16691335.12 |
| EMP_119 | non_leadership | Balance | $290161.73 | ₹27231678.36 |
| EMP_120 | non_leadership | Balance | $168268.96 | ₹15792041.90 |

OSS Fee This Month:
| GCC Headcount | Slab | Amount USD | Amount INR |
|---------------|------|------------|------------|
| 112 | OSS_PER_HEAD_51_250 | $39424.00 | ₹3699942.40 |

Monthly Total (USD): $8529240.94
Monthly Total (INR): ₹800469262.22