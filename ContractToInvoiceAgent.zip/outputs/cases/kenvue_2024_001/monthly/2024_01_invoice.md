Invoice #: kenvue_2024_001-2024-01
Period: Month 2024-01

TA Fees Due This Month:
| Employee ID | Type | Fee Type | Amount USD | Amount INR |
|-------------|------|----------|------------|------------|
| EMP_070 | manager | Sourcing | $400.00 | ₹37540.00 |
| EMP_071 | non_leadership | Sourcing | $400.00 | ₹37540.00 |
| EMP_076 | non_leadership | Sourcing | $400.00 | ₹37540.00 |
| EMP_077 | non_leadership | Sourcing | $400.00 | ₹37540.00 |
| EMP_080 | manager | Sourcing | $400.00 | ₹37540.00 |
| EMP_081 | non_leadership | Sourcing | $400.00 | ₹37540.00 |
| EMP_088 | non_leadership | Sourcing | $400.00 | ₹37540.00 |
| EMP_090 | manager | Sourcing | $400.00 | ₹37540.00 |
| EMP_091 | manager | Sourcing | $400.00 | ₹37540.00 |
| EMP_097 | non_leadership | Sourcing | $400.00 | ₹37540.00 |
| EMP_099 | non_leadership | Sourcing | $400.00 | ₹37540.00 |
| EMP_103 | non_leadership | Sourcing | $400.00 | ₹37540.00 |
| EMP_109 | non_leadership | Sourcing | $400.00 | ₹37540.00 |
| EMP_115 | non_leadership | Sourcing | $400.00 | ₹37540.00 |
| EMP_123 | manager | Sourcing | $400.00 | ₹37540.00 |
| EMP_125 | non_leadership | Sourcing | $400.00 | ₹37540.00 |
| EMP_127 | non_leadership | Sourcing | $400.00 | ₹37540.00 |
| EMP_133 | non_leadership | Sourcing | $400.00 | ₹37540.00 |
| EMP_134 | non_leadership | Sourcing | $400.00 | ₹37540.00 |
| EMP_135 | non_leadership | Sourcing | $400.00 | ₹37540.00 |
| EMP_136 | manager | Sourcing | $400.00 | ₹37540.00 |
| EMP_140 | non_leadership | Sourcing | $400.00 | ₹37540.00 |
| EMP_141 | manager | Sourcing | $400.00 | ₹37540.00 |
| EMP_144 | manager | Sourcing | $400.00 | ₹37540.00 |
| EMP_145 | non_leadership | Sourcing | $400.00 | ₹37540.00 |
| EMP_148 | non_leadership | Sourcing | $400.00 | ₹37540.00 |
| EMP_149 | non_leadership | Sourcing | $400.00 | ₹37540.00 |
| EMP_151 | non_leadership | Sourcing | $400.00 | ₹37540.00 |
| EMP_153 | manager | Sourcing | $400.00 | ₹37540.00 |
| EMP_154 | non_leadership | Sourcing | $400.00 | ₹37540.00 |
| EMP_159 | manager | Sourcing | $400.00 | ₹37540.00 |
| EMP_164 | non_leadership | Sourcing | $400.00 | ₹37540.00 |
| EMP_176 | non_leadership | Sourcing | $400.00 | ₹37540.00 |
| EMP_178 | non_leadership | Sourcing | $400.00 | ₹37540.00 |
| EMP_191 | manager | Sourcing | $400.00 | ₹37540.00 |
| EMP_192 | non_leadership | Sourcing | $400.00 | ₹37540.00 |
| EMP_194 | non_leadership | Sourcing | $400.00 | ₹37540.00 |
| EMP_198 | manager | Sourcing | $400.00 | ₹37540.00 |
| EMP_199 | non_leadership | Sourcing | $400.00 | ₹37540.00 |
| EMP_202 | manager | Sourcing | $400.00 | ₹37540.00 |
| EMP_210 | non_leadership | Sourcing | $400.00 | ₹37540.00 |
| EMP_211 | non_leadership | Sourcing | $400.00 | ₹37540.00 |
| EMP_212 | non_leadership | Sourcing | $400.00 | ₹37540.00 |
| EMP_228 | non_leadership | Sourcing | $400.00 | ₹37540.00 |
| EMP_233 | non_leadership | Sourcing | $400.00 | ₹37540.00 |
| EMP_238 | manager | Sourcing | $400.00 | ₹37540.00 |
| EMP_239 | non_leadership | Sourcing | $400.00 | ₹37540.00 |
| EMP_246 | non_leadership | Sourcing | $400.00 | ₹37540.00 |
| EMP_254 | non_leadership | Sourcing | $400.00 | ₹37540.00 |
| EMP_256 | manager | Sourcing | $400.00 | ₹37540.00 |
| EMP_258 | manager | Sourcing | $400.00 | ₹37540.00 |
| EMP_264 | non_leadership | Sourcing | $400.00 | ₹37540.00 |
| EMP_282 | non_leadership | Sourcing | $400.00 | ₹37540.00 |
| EMP_355 | non_leadership | Sourcing | $400.00 | ₹37540.00 |
| EMP_364 | manager | Sourcing | $400.00 | ₹37540.00 |
| EMP_046 | non_leadership | Acceptance | $600.00 | ₹56310.00 |
| EMP_047 | non_leadership | Acceptance | $600.00 | ₹56310.00 |
| EMP_063 | non_leadership | Acceptance | $600.00 | ₹56310.00 |
| EMP_070 | manager | Acceptance | $600.00 | ₹56310.00 |
| EMP_073 | non_leadership | Acceptance | $600.00 | ₹56310.00 |
| EMP_085 | non_leadership | Acceptance | $300.00 | ₹28155.00 |
| EMP_105 | manager | Acceptance | $300.00 | ₹28155.00 |
| EMP_016 | non_leadership | Balance | $151600.00 | ₹14227660.00 |
| EMP_017 | manager | Balance | $779000.00 | ₹73109150.00 |
| EMP_018 | non_leadership | Balance | $271500.00 | ₹25480275.00 |
| EMP_019 | manager | Balance | $356500.00 | ₹33457525.00 |
| EMP_020 | non_leadership | Balance | $353250.00 | ₹33152512.50 |

OSS Fee This Month:
| GCC Headcount | Slab | Amount USD | Amount INR |
|---------------|------|------------|------------|
| 42 | OSS_FLAT | $17600.00 | ₹1651760.00 |

Monthly Total (USD): $1955050.00
Monthly Total (INR): ₹183481442.50