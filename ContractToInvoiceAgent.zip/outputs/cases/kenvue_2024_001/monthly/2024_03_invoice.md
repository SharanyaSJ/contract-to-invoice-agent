Invoice #: kenvue_2024_001-2024-03
Period: Month 2024-03

TA Fees Due This Month:
| Employee ID | Type | Fee Type | Amount USD | Amount INR |
|-------------|------|----------|------------|------------|
| EMP_117 | non_leadership | Sourcing | $400.00 | ₹37540.00 |
| EMP_131 | non_leadership | Sourcing | $400.00 | ₹37540.00 |
| EMP_174 | non_leadership | Sourcing | $400.00 | ₹37540.00 |
| EMP_200 | non_leadership | Sourcing | $300.00 | ₹28155.00 |
| EMP_219 | non_leadership | Sourcing | $400.00 | ₹37540.00 |
| EMP_265 | non_leadership | Sourcing | $400.00 | ₹37540.00 |
| EMP_071 | non_leadership | Acceptance | $600.00 | ₹56310.00 |
| EMP_074 | non_leadership | Acceptance | $300.00 | ₹28155.00 |
| EMP_076 | non_leadership | Acceptance | $600.00 | ₹56310.00 |
| EMP_077 | non_leadership | Acceptance | $600.00 | ₹56310.00 |
| EMP_080 | manager | Acceptance | $600.00 | ₹56310.00 |
| EMP_081 | non_leadership | Acceptance | $600.00 | ₹56310.00 |
| EMP_087 | non_leadership | Acceptance | $600.00 | ₹56310.00 |
| EMP_104 | non_leadership | Acceptance | $600.00 | ₹56310.00 |
| EMP_109 | non_leadership | Acceptance | $600.00 | ₹56310.00 |
| EMP_117 | non_leadership | Acceptance | $600.00 | ₹56310.00 |
| EMP_119 | non_leadership | Acceptance | $600.00 | ₹56310.00 |
| EMP_122 | manager | Acceptance | $600.00 | ₹56310.00 |
| EMP_128 | director | Acceptance | $600.00 | ₹56310.00 |
| EMP_130 | non_leadership | Acceptance | $600.00 | ₹56310.00 |
| EMP_134 | non_leadership | Acceptance | $600.00 | ₹56310.00 |
| EMP_140 | non_leadership | Acceptance | $600.00 | ₹56310.00 |
| EMP_141 | manager | Acceptance | $600.00 | ₹56310.00 |
| EMP_142 | manager | Acceptance | $600.00 | ₹56310.00 |
| EMP_144 | manager | Acceptance | $600.00 | ₹56310.00 |
| EMP_145 | non_leadership | Acceptance | $600.00 | ₹56310.00 |
| EMP_149 | non_leadership | Acceptance | $600.00 | ₹56310.00 |
| EMP_155 | manager | Acceptance | $600.00 | ₹56310.00 |
| EMP_156 | non_leadership | Acceptance | $600.00 | ₹56310.00 |
| EMP_159 | manager | Acceptance | $600.00 | ₹56310.00 |
| EMP_167 | non_leadership | Acceptance | $600.00 | ₹56310.00 |
| EMP_177 | manager | Acceptance | $600.00 | ₹56310.00 |
| EMP_185 | non_leadership | Acceptance | $600.00 | ₹56310.00 |
| EMP_187 | non_leadership | Acceptance | $600.00 | ₹56310.00 |
| EMP_190 | non_leadership | Acceptance | $600.00 | ₹56310.00 |
| EMP_044 | non_leadership | Balance | $238557.50 | ₹22388621.38 |
| EMP_045 | manager | Balance | $485970.00 | ₹45608284.50 |
| EMP_046 | non_leadership | Balance | $313951.10 | ₹29464310.73 |
| EMP_047 | non_leadership | Balance | $163139.56 | ₹15310647.71 |
| EMP_048 | director | Balance | $1127767.49 | ₹105840978.94 |
| EMP_049 | manager | Balance | $429766.53 | ₹40333588.84 |
| EMP_050 | non_leadership | Balance | $286300.00 | ₹26869255.00 |
| EMP_051 | manager | Balance | $569000.00 | ₹53400650.00 |
| EMP_052 | non_leadership | Balance | $156592.42 | ₹14696198.62 |
| EMP_053 | non_leadership | Balance | $199445.13 | ₹18717925.45 |
| EMP_054 | manager | Balance | $516750.00 | ₹48496987.50 |
| EMP_055 | non_leadership | Balance | $100399.92 | ₹9422532.49 |
| EMP_057 | manager | Balance | $702000.00 | ₹65882700.00 |

OSS Fee This Month:
| GCC Headcount | Slab | Amount USD | Amount INR |
|---------------|------|------------|------------|
| 69 | OSS_PER_HEAD_51_250 | $24288.00 | ₹2279428.80 |

Monthly Total (USD): $5333327.65
Monthly Total (INR): ₹500532799.95