Invoice #: kenvue_2024_001-2025-06
Period: Month 2025-06

TA Fees Due This Month:
| Employee ID | Type | Fee Type | Amount USD | Amount INR |
|-------------|------|----------|------------|------------|
| EMP_625 | manager | Sourcing | $400.00 | ₹37540.00 |
| EMP_340 | non_leadership | Acceptance | $600.00 | ₹56310.00 |
| EMP_341 | non_leadership | Acceptance | $600.00 | ₹56310.00 |
| EMP_417 | non_leadership | Acceptance | $600.00 | ₹56310.00 |
| EMP_426 | non_leadership | Acceptance | $600.00 | ₹56310.00 |
| EMP_506 | manager | Acceptance | $600.00 | ₹56310.00 |
| EMP_518 | non_leadership | Acceptance | $600.00 | ₹56310.00 |
| EMP_522 | non_leadership | Acceptance | $600.00 | ₹56310.00 |
| EMP_528 | manager | Acceptance | $600.00 | ₹56310.00 |
| EMP_533 | manager | Acceptance | $600.00 | ₹56310.00 |
| EMP_555 | non_leadership | Acceptance | $600.00 | ₹56310.00 |
| EMP_587 | non_leadership | Acceptance | $600.00 | ₹56310.00 |
| EMP_589 | manager | Acceptance | $600.00 | ₹56310.00 |
| EMP_590 | manager | Acceptance | $600.00 | ₹56310.00 |
| EMP_592 | non_leadership | Acceptance | $600.00 | ₹56310.00 |
| EMP_593 | non_leadership | Acceptance | $600.00 | ₹56310.00 |
| EMP_601 | manager | Acceptance | $600.00 | ₹56310.00 |
| EMP_602 | non_leadership | Acceptance | $600.00 | ₹56310.00 |
| EMP_630 | non_leadership | Acceptance | $600.00 | ₹56310.00 |
| EMP_631 | non_leadership | Acceptance | $600.00 | ₹56310.00 |
| EMP_632 | non_leadership | Acceptance | $600.00 | ₹56310.00 |
| EMP_638 | non_leadership | Acceptance | $600.00 | ₹56310.00 |
| EMP_640 | manager | Acceptance | $600.00 | ₹56310.00 |
| EMP_646 | non_leadership | Acceptance | $600.00 | ₹56310.00 |
| EMP_660 | non_leadership | Acceptance | $600.00 | ₹56310.00 |
| EMP_661 | non_leadership | Acceptance | $600.00 | ₹56310.00 |
| EMP_662 | non_leadership | Acceptance | $600.00 | ₹56310.00 |
| EMP_663 | non_leadership | Acceptance | $600.00 | ₹56310.00 |
| EMP_685 | non_leadership | Acceptance | $600.00 | ₹56310.00 |
| EMP_251 | non_leadership | Balance | $206002.18 | ₹19333304.59 |
| EMP_281 | non_leadership | Balance | $186995.64 | ₹17549540.81 |
| EMP_312 | manager | Balance | $-1000.00 | ₹-93850.00 |
| EMP_402 | manager | Balance | $671221.14 | ₹62994103.99 |
| EMP_461 | non_leadership | Balance | $120921.00 | ₹11348435.85 |
| EMP_463 | manager | Balance | $318238.73 | ₹29866704.81 |
| EMP_464 | manager | Balance | $419722.12 | ₹39390920.96 |
| EMP_473 | manager | Balance | $-1000.00 | ₹-93850.00 |
| EMP_479 | non_leadership | Balance | $-1000.00 | ₹-93850.00 |
| EMP_480 | non_leadership | Balance | $-1000.00 | ₹-93850.00 |
| EMP_483 | non_leadership | Balance | $-1000.00 | ₹-93850.00 |
| EMP_488 | non_leadership | Balance | $222786.97 | ₹20908557.13 |
| EMP_489 | non_leadership | Balance | $102789.13 | ₹9646759.85 |
| EMP_499 | non_leadership | Balance | $298280.23 | ₹27993599.59 |
| EMP_500 | non_leadership | Balance | $-1000.00 | ₹-93850.00 |
| EMP_502 | non_leadership | Balance | $136382.11 | ₹12799461.02 |
| EMP_504 | non_leadership | Balance | $114668.64 | ₹10761651.86 |
| EMP_505 | non_leadership | Balance | $-1000.00 | ₹-93850.00 |
| EMP_513 | non_leadership | Balance | $102036.62 | ₹9576136.79 |
| EMP_514 | non_leadership | Balance | $106943.08 | ₹10036608.06 |
| EMP_524 | manager | Balance | $431778.86 | ₹40522446.01 |
| EMP_534 | non_leadership | Balance | $278328.21 | ₹26121102.51 |
| EMP_547 | manager | Balance | $-1000.00 | ₹-93850.00 |
| EMP_548 | manager | Balance | $-1000.00 | ₹-93850.00 |
| EMP_625 | manager | Balance | $-1000.00 | ₹-93850.00 |
| EMP_626 | non_leadership | Balance | $-1000.00 | ₹-93850.00 |

OSS Fee This Month:
| GCC Headcount | Slab | Amount USD | Amount INR |
|---------------|------|------------|------------|
| 405 | OSS_PER_HEAD_51_250 | $142560.00 | ₹13379256.00 |

Monthly Total (USD): $3865854.66
Monthly Total (INR): ₹362810459.84