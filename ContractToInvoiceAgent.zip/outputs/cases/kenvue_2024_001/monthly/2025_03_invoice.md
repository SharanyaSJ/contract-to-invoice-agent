Invoice #: kenvue_2024_001-2025-03
Period: Month 2025-03

TA Fees Due This Month:
| Employee ID | Type | Fee Type | Amount USD | Amount INR |
|-------------|------|----------|------------|------------|
| EMP_488 | non_leadership | Sourcing | $400.00 | ₹37540.00 |
| EMP_489 | non_leadership | Sourcing | $400.00 | ₹37540.00 |
| EMP_504 | non_leadership | Sourcing | $400.00 | ₹37540.00 |
| EMP_505 | non_leadership | Sourcing | $400.00 | ₹37540.00 |
| EMP_518 | non_leadership | Sourcing | $400.00 | ₹37540.00 |
| EMP_519 | non_leadership | Sourcing | $400.00 | ₹37540.00 |
| EMP_522 | non_leadership | Sourcing | $400.00 | ₹37540.00 |
| EMP_524 | manager | Sourcing | $400.00 | ₹37540.00 |
| EMP_525 | non_leadership | Sourcing | $400.00 | ₹37540.00 |
| EMP_528 | manager | Sourcing | $400.00 | ₹37540.00 |
| EMP_529 | manager | Sourcing | $400.00 | ₹37540.00 |
| EMP_533 | manager | Sourcing | $400.00 | ₹37540.00 |
| EMP_539 | manager | Sourcing | $400.00 | ₹37540.00 |
| EMP_540 | non_leadership | Sourcing | $400.00 | ₹37540.00 |
| EMP_543 | manager | Sourcing | $400.00 | ₹37540.00 |
| EMP_559 | non_leadership | Sourcing | $400.00 | ₹37540.00 |
| EMP_592 | non_leadership | Sourcing | $400.00 | ₹37540.00 |
| EMP_596 | manager | Sourcing | $400.00 | ₹37540.00 |
| EMP_597 | manager | Sourcing | $400.00 | ₹37540.00 |
| EMP_628 | manager | Sourcing | $400.00 | ₹37540.00 |
| EMP_168 | non_leadership | Acceptance | $600.00 | ₹56310.00 |
| EMP_377 | non_leadership | Acceptance | $600.00 | ₹56310.00 |
| EMP_409 | manager | Acceptance | $600.00 | ₹56310.00 |
| EMP_419 | non_leadership | Acceptance | $600.00 | ₹56310.00 |
| EMP_429 | non_leadership | Acceptance | $600.00 | ₹56310.00 |
| EMP_440 | non_leadership | Acceptance | $600.00 | ₹56310.00 |
| EMP_451 | manager | Acceptance | $600.00 | ₹56310.00 |
| EMP_452 | non_leadership | Acceptance | $600.00 | ₹56310.00 |
| EMP_460 | manager | Acceptance | $600.00 | ₹56310.00 |
| EMP_467 | non_leadership | Acceptance | $600.00 | ₹56310.00 |
| EMP_472 | manager | Acceptance | $600.00 | ₹56310.00 |
| EMP_473 | manager | Acceptance | $600.00 | ₹56310.00 |
| EMP_477 | non_leadership | Acceptance | $600.00 | ₹56310.00 |
| EMP_479 | non_leadership | Acceptance | $600.00 | ₹56310.00 |
| EMP_500 | non_leadership | Acceptance | $600.00 | ₹56310.00 |
| EMP_505 | non_leadership | Acceptance | $600.00 | ₹56310.00 |
| EMP_507 | non_leadership | Acceptance | $600.00 | ₹56310.00 |
| EMP_526 | non_leadership | Acceptance | $600.00 | ₹56310.00 |
| EMP_530 | manager | Acceptance | $600.00 | ₹56310.00 |
| EMP_534 | non_leadership | Acceptance | $600.00 | ₹56310.00 |
| EMP_556 | manager | Acceptance | $600.00 | ₹56310.00 |
| EMP_208 | manager | Balance | $-1000.00 | ₹-93850.00 |
| EMP_286 | manager | Balance | $-1000.00 | ₹-93850.00 |
| EMP_330 | non_leadership | Balance | $103414.40 | ₹9705441.44 |
| EMP_354 | non_leadership | Balance | $137684.87 | ₹12921725.05 |
| EMP_364 | manager | Balance | $529841.55 | ₹49725629.47 |
| EMP_365 | non_leadership | Balance | $184963.82 | ₹17358854.51 |
| EMP_366 | non_leadership | Balance | $207027.30 | ₹19429512.10 |
| EMP_369 | non_leadership | Balance | $251393.03 | ₹23593235.87 |
| EMP_387 | non_leadership | Balance | $-1000.00 | ₹-93850.00 |
| EMP_390 | manager | Balance | $-1000.00 | ₹-93850.00 |
| EMP_391 | manager | Balance | $545945.31 | ₹51236967.34 |
| EMP_394 | non_leadership | Balance | $333196.29 | ₹31270471.82 |
| EMP_396 | manager | Balance | $405571.04 | ₹38062842.10 |
| EMP_397 | non_leadership | Balance | $200723.44 | ₹18837894.84 |
| EMP_412 | non_leadership | Balance | $-1000.00 | ₹-93850.00 |
| EMP_427 | non_leadership | Balance | $-1000.00 | ₹-93850.00 |
| EMP_428 | non_leadership | Balance | $-1000.00 | ₹-93850.00 |
| EMP_430 | non_leadership | Balance | $204409.99 | ₹19183877.56 |
| EMP_450 | non_leadership | Balance | $-1000.00 | ₹-93850.00 |

OSS Fee This Month:
| GCC Headcount | Slab | Amount USD | Amount INR |
|---------------|------|------------|------------|
| 326 | OSS_PER_HEAD_51_250 | $114752.00 | ₹10769475.20 |

Monthly Total (USD): $3231523.04
Monthly Total (INR): ₹303278437.30