# ContractToInvoiceAgent — Orchestrator

## Purpose
Defines the routing logic, stage progression, and error handling for a multi-case ContractToInvoiceAgent pipeline.

---

## 1) Multi‑Case Awareness
- At session start, the agent **must accept a `case_id`** (e.g., `prudent_insurance_2024_q1`).
- All file reads/writes are **scoped** to:
  - Inputs: `data/cases/{case_id}/`
  - Outputs: `outputs/cases/{case_id}/`
- Multiple cases may exist simultaneously; **never mix data** between cases.

---

## 2) Session Initialization (Run at Start of Every Session)
Write this **exact block** to `memory/session_state.json`:

```
{
  "case_id": "{case_id}",
  "contract_file": "data/cases/{case_id}/contract.pdf",
  "excel_file": "data/cases/{case_id}/workforce.xlsx",
  "stage_completed": [],
  "stage_current": "S0_upload_verification",
  "errors": [],
  "rules_extracted": false,
  "excel_ingested": false,
  "invoice_ready": false,
  "created_at": "{timestamp}"
}
```

---

## 3) Stage Routing Table (Pipeline Order)
**S0 → S1 → S2 → S3A → S3B → S4 → S5 → S6 → S7(optional)**

**S0: Upload Verification**
- Verify both files exist in `data/cases/{case_id}/`
  - `contract.pdf`
  - `workforce.xlsx`

**S1: Contract Rule Extraction**
- Extract fee rules and schedules from the contract.
- **BLOCK if fails — do not proceed.**

**S2: Excel Ingestion & Normalization**
- Read workforce data and normalize columns/values.

**S3A: Rule Mapping**
- Map each employee row to applicable rules.

**S3B: Fee Computation**
- Compute TA fee, payment split, OSS fee.

**S4: Invoice Structuring**
- Group by required dimensions (client, region, month, etc.).

**S5: Invoice Generation**
- Produce output files in `outputs/cases/{case_id}/`.

**S6: Validation & Audit**
- Compare computed totals vs. expected totals; log anomalies.

**S7: Learning Updater (Optional)**
- Store reusable patterns to improve future runs.

---

## 4) Error Handling Rules
- **If S1 fails:** STOP. Write error to `session_state.json`. Do not run S2+.
- **If S2 fails:** STOP on Excel issues. Prompt user to fix column mapping.
- **If S3B produces a negative fee:** FLAG as anomaly, log to audit, continue.
- **If S6 finds mismatches:** Re-run S3B for flagged employees only, then re-run S6.

---

## 5) How to Call Each Skill
Each stage specifies: **skill → input → expected output → success condition**

### S0 — Upload Verification
- **Skill:** `contract_ingestion` (verification mode)
- **Input:**
  - `data/cases/{case_id}/contract.pdf`
  - `data/cases/{case_id}/workforce.xlsx`
- **Expected Output:**
  - `files_verified = true`
  - `missing_files = []`
- **Success Condition:** Both files present and readable.

### S1 — Contract Rule Extraction
- **Skill:** `rule_extractor`
- **Input:** `data/cases/{case_id}/contract.pdf`
- **Expected Output:** Structured rule candidates (fees, payment schedules, constraints)
- **Success Condition:** `rules_extracted = true` with non-empty rules.

### S2 — Excel Ingestion & Normalization
- **Skill:** `excel_ingestion` → `data_normalizer`
- **Input:** `data/cases/{case_id}/workforce.xlsx`, `data/schema/excel_column_map.json`
- **Expected Output:** Cleaned, normalized employee table
- **Success Condition:** `excel_ingested = true` and no blocking schema errors.

### S3A — Rule Mapping
- **Skill:** `rule_mapper`
- **Input:** Normalized employee table + extracted rules
- **Expected Output:** Row-level rule assignments
- **Success Condition:** Each employee row has applicable rule(s) or an explicit exception.

### S3B — Fee Computation
- **Skill:** `computation_engine` + `fee_calculator`
- **Input:** Rule-mapped employee rows
- **Expected Output:** Fee breakdown per employee (TA, OSS, payment split)
- **Success Condition:** Computations complete; negative fees only flagged as anomalies.

### S4 — Invoice Structuring
- **Skill:** `invoice_structurer`
- **Input:** Computed fee table
- **Expected Output:** Structured invoice groups (by period, client, service type)
- **Success Condition:** Structured invoice objects created with totals.

### S5 — Invoice Generation
- **Skill:** `invoice_generator`
- **Input:** Structured invoice objects + templates
- **Expected Output:** Invoice files saved in `outputs/cases/{case_id}/`
- **Success Condition:** Output files created and linked to case.

### S6 — Validation & Audit
- **Skill:** `validation_engine` + `audit_checker`
- **Input:** Generated invoices + computed fee table
- **Expected Output:** Validation report, audit log
- **Success Condition:** No critical mismatches; rerun S3B for flagged rows if needed.

### S7 — Learning Updater (Optional)
- **Skill:** `learning_updater`
- **Input:** Rules, mapping exceptions, validation results
- **Expected Output:** Updated reusable patterns / rule hints
- **Success Condition:** Learning artifacts stored for future cases.
